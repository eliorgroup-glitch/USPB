import Link from "next/link";
import { fcfa, propertyHref } from "@/lib/format";
import { VerificationBadge } from "./VerificationBadge";
export function PropertyCard({ p }: { p: any }) {
  return (
    <Link href={propertyHref(p)} className="block overflow-hidden rounded-xl border border-line bg-white hover:border-brand">
      <div className="flex aspect-[16/10] items-center justify-center bg-brand-soft text-sm text-brand-dark">
        {p.images?.[0] ? <img src={`/api/files/${p.images[0].storageKey}`} alt="" className="h-full w-full object-cover" /> : "Aucune photo"}
      </div>
      <div className="space-y-2 p-4">
        <VerificationBadge level={p.verificationBadge} />
        <h3 className="font-display text-lg font-semibold leading-snug">{p.title}</h3>
        <p className="text-sm text-ink/70">{[p.district, p.commune, p.city].filter(Boolean).join(", ")} · {Number(p.land?.areaSqm)} m²</p>
        <p className="text-xl font-bold text-brand-dark">{fcfa(p.price)}</p>
        <p className="text-xs text-ink/60">Réf. {p.reference}</p>
      </div>
    </Link>
  );
}
