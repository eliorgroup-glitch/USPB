"use client";
import { useState } from "react";
import Link from "next/link";
const REASONS: [string, string][] = [["WRONG_INFO", "Informations incorrectes"], ["WRONG_PRICE", "Prix incorrect"], ["ALREADY_SOLD", "Terrain déjà vendu"],
  ["SUSPICIOUS_DOCUMENT", "Document suspect"], ["WRONG_LOCATION", "Localisation incorrecte"], ["FRAUD", "Contenu frauduleux"], ["OTHER", "Autre"]];
export function PropertyActions({ propertyId, role }: { propertyId: string; role: string | null }) {
  const [panel, setPanel] = useState<"" | "visit" | "contact" | "report">("");
  const [fav, setFav] = useState<boolean | null>(null); const [msg, setMsg] = useState(""); const [err, setErr] = useState("");
  if (!role) return <Link href="/connexion" className="btn-primary w-full">Connectez-vous pour demander une visite</Link>;
  if (role !== "BUYER") return <p className="text-sm text-ink/60">Les actions acheteur sont réservées aux comptes acheteurs.</p>;
  async function send(url: string, data: unknown, ok: string) {
    setErr(""); setMsg("");
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return setErr(j.issues ? "Vérifiez les champs saisis." : j.error ?? "Action impossible.");
    setMsg(ok); setPanel(""); return j;
  }
  const submit = (fn: (f: Record<string, string>) => Promise<unknown>) => (e: React.FormEvent<HTMLFormElement>) => { e.preventDefault(); fn(Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>); };
  return (<div className="space-y-2">
    <button className="btn-primary w-full" onClick={() => setPanel(panel === "visit" ? "" : "visit")}>Demander une visite</button>
    <button className="btn-ghost w-full" onClick={() => setPanel(panel === "contact" ? "" : "contact")}>Contacter USPB</button>
    <button className="btn-ghost w-full" aria-pressed={!!fav} onClick={async () => { const j = await send("/api/favorites", { propertyId }, ""); if (j) { setFav(j.favorited); setMsg(j.favorited ? "Ajouté aux favoris." : "Retiré des favoris."); } }}>{fav ? "Retirer des favoris" : "Ajouter aux favoris"}</button>
    <button className="w-full text-sm underline" onClick={() => setPanel(panel === "report" ? "" : "report")}>Signaler cette annonce</button>
    {panel === "visit" && <form className="space-y-2" onSubmit={submit((f) => send(`/api/properties/${propertyId}/visit`, { requestedAt: new Date(f.requestedAt).toISOString(), people: f.people, comment: f.comment || undefined }, "Demande de visite envoyée."))}>
      <label className="label" htmlFor="requestedAt">Date et heure souhaitées</label><input id="requestedAt" name="requestedAt" type="datetime-local" required className="field" />
      <label className="label" htmlFor="people">Nombre de personnes</label><input id="people" name="people" type="number" min={1} max={20} defaultValue={1} className="field" />
      <label className="label" htmlFor="vc">Commentaire</label><textarea id="vc" name="comment" rows={2} className="field py-2" /><button className="btn-primary w-full">Envoyer la demande</button></form>}
    {panel === "contact" && <form className="space-y-2" onSubmit={submit((f) => send(`/api/properties/${propertyId}/messages`, { body: f.body }, "Message envoyé à USPB. Réponse dans votre espace."))}>
      <label className="label" htmlFor="body">Votre message à USPB</label><textarea id="body" name="body" rows={3} required className="field py-2" /><button className="btn-primary w-full">Envoyer</button></form>}
    {panel === "report" && <form className="space-y-2" onSubmit={submit((f) => send("/api/reports", { propertyId, reason: f.reason, details: f.details || undefined }, "Signalement transmis à USPB."))}>
      <label className="label" htmlFor="reason">Motif</label><select id="reason" name="reason" className="field">{REASONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
      <label className="label" htmlFor="details">Détails</label><textarea id="details" name="details" rows={2} className="field py-2" /><button className="btn-primary w-full">Signaler</button></form>}
    {err && <p role="alert" className="text-sm text-red-700">{err}</p>}{msg && <p role="status" className="text-sm text-emerald-800">{msg}</p>}</div>);
}
