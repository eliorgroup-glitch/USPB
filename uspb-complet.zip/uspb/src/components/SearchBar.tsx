export function SearchBar() {
  return (
    <form action="/terrains" className="grid gap-2 rounded-xl border border-line bg-white p-3 sm:grid-cols-[1fr_1fr_auto]" role="search">
      <div><label htmlFor="city" className="label">Ville</label><input id="city" name="city" placeholder="Dimbokro" className="field" /></div>
      <div><label htmlFor="maxPrice" className="label">Budget maximum (FCFA)</label><input id="maxPrice" name="maxPrice" type="number" min="0" inputMode="numeric" className="field" /></div>
      <button className="btn-primary self-end">Rechercher un terrain</button>
    </form>
  );
}
