"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export type Field = { name: string; label: string; type?: string; options?: [string, string][]; required?: boolean; step?: string };
/** Formulaire générique : envoie du JSON à une API puis rafraîchit la page. Un nom "a.b" produit { a: { b } }. */
export function ApiForm({ url, method = "POST", fields, submit, extra }: { url: string; method?: string; fields: Field[]; submit: string; extra?: Record<string, unknown> }) {
  const r = useRouter(); const [err, setErr] = useState(""); const [ok, setOk] = useState(""); const [busy, setBusy] = useState(false);
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const form = e.currentTarget; const fd = new FormData(form);
    const body: Record<string, any> = { ...extra };
    for (const f of fields) {
      const v = String(fd.get(f.name) ?? ""); if (v === "") continue;
      const val = f.type === "number" ? Number(v) : f.type === "datetime-local" ? new Date(v).toISOString() : v;
      const [a, b] = f.name.split("."); if (b) (body[a] ??= {})[b] = val; else body[a] = val;
    }
    setBusy(true); setErr(""); setOk("");
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const j = await res.json().catch(() => ({})); setBusy(false);
    if (!res.ok) return setErr(j.issues ? "Vérifiez les champs saisis." : j.error ?? "Action impossible.");
    form.reset(); setOk("Enregistré."); r.refresh();
  }
  return (<form onSubmit={onSubmit} className="grid gap-3 rounded-xl border border-line bg-white p-4 sm:grid-cols-2">
    {fields.map((f) => <div key={f.name}><label className="label" htmlFor={`${url}${f.name}`}>{f.label}</label>
      {f.options ? <select id={`${url}${f.name}`} name={f.name} required={f.required} className="field">{f.options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
        : <input id={`${url}${f.name}`} name={f.name} type={f.type ?? "text"} step={f.step} required={f.required} className="field" />}</div>)}
    <div className="sm:col-span-2"><button className="btn-primary" disabled={busy}>{busy ? "Envoi…" : submit}</button>
      {err && <p role="alert" className="mt-2 text-sm text-red-700">{err}</p>}{ok && <p role="status" className="mt-2 text-sm text-emerald-800">{ok}</p>}</div></form>);
}
