import Link from "next/link";
import { auth, signOut } from "@/lib/auth";
export async function Header() {
  const s = await auth();
  const role = s?.user.role;
  return (
    <header className="border-b border-line bg-white">
      <nav className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-5 gap-y-2 px-4 py-3" aria-label="Navigation principale">
        <Link href="/" className="font-display text-2xl font-extrabold text-brand">USPB</Link>
        <Link href="/terrains" className="text-sm font-medium">Terrains</Link>
        <Link href="/comment-ca-marche" className="text-sm font-medium">Comment ça marche</Link>
        <Link href="/a-propos" className="text-sm font-medium">À propos</Link>
        {s && <Link href="/dashboard" className="text-sm font-medium">Tableau de bord</Link>}
        <div className="ml-auto flex items-center gap-3">
          {role === "OWNER" && <Link href="/deposer" className="btn-primary">Vendre mon terrain</Link>}
          {s ? (
            <form action={async () => { "use server"; await signOut({ redirectTo: "/" }); }}>
              <button className="btn-ghost" aria-label={`Se déconnecter (${s.user.name})`}>Déconnexion</button>
            </form>
          ) : (<><Link href="/connexion" className="btn-ghost">Connexion</Link><Link href="/inscription" className="btn-primary">Créer un compte</Link></>)}
        </div>
      </nav>
    </header>
  );
}
