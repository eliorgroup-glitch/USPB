"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export function ApiButton({ url, method = "PATCH", body, label }: { url: string; method?: string; body: unknown; label: string }) {
  const r = useRouter(); const [err, setErr] = useState("");
  async function go() {
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (!res.ok) return setErr((await res.json().catch(() => ({}))).error ?? "Action impossible."); setErr(""); r.refresh();
  }
  return <span className="inline-flex flex-col"><button onClick={go} className="btn-ghost !min-h-9 !px-3 text-sm">{label}</button>{err && <span role="alert" className="max-w-xs text-xs text-red-700">{err}</span>}</span>;
}
