const B = {
  GREEN: { cls: "bg-emerald-100 text-emerald-900", dot: "🟢", text: "Vérifié selon la procédure USPB" },
  ORANGE: { cls: "bg-amber-100 text-amber-900", dot: "🟠", text: "Vérification en cours" },
  RED: { cls: "bg-red-100 text-red-900", dot: "🔴", text: "Anomalie à clarifier" },
} as const;
export function VerificationBadge({ level }: { level: keyof typeof B }) {
  const b = B[level];
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-semibold ${b.cls}`}><span aria-hidden>{b.dot}</span>{b.text}</span>;
}
