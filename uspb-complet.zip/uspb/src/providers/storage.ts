import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";
export interface StorageProvider { put(key: string, data: Buffer): Promise<void>; get(key: string): Promise<Buffer | null>; }
const root = path.resolve(process.env.STORAGE_LOCAL_DIR ?? "./.storage");
const local: StorageProvider = {
  async put(key, data) { const f = file(key); await fs.mkdir(path.dirname(f), { recursive: true }); await fs.writeFile(f, data); },
  async get(key) { try { return await fs.readFile(file(key)); } catch { return null; } },
};
function file(key: string) {
  if (!/^[a-z0-9][a-z0-9/_.-]*$/i.test(key) || key.includes("..")) throw new Error("Clé de fichier invalide");
  return path.join(root, key);
}
export function getStorage(): StorageProvider {
  if ((process.env.STORAGE_DRIVER ?? "local") !== "local")
    throw new Error("Driver de stockage non implémenté : écrire un StorageProvider S3 (endpoint, bucket, clés) dans src/providers/.");
  return local;
}
const mac = (key: string, exp: number) => crypto.createHmac("sha256", process.env.AUTH_SECRET!).update(`${key}:${exp}`).digest("hex");
export function signedPath(key: string) {
  const exp = Math.floor(Date.now() / 1000) + Number(process.env.SIGNED_URL_TTL_SECONDS ?? 300);
  return `/api/files/${key}?exp=${exp}&sig=${mac(key, exp)}`;
}
export function validSignature(key: string, exp: number, sig: string) {
  if (!exp || exp < Date.now() / 1000 || sig.length !== 64) return false;
  return crypto.timingSafeEqual(Buffer.from(mac(key, exp)), Buffer.from(sig));
}
/** Détection par octets magiques (on ne fait pas confiance au type MIME envoyé). */
export function sniff(b: Buffer): { mime: string; ext: string } | null {
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (b.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]))) return { mime: "image/png", ext: "png" };
  if (b.subarray(0, 4).toString() === "RIFF" && b.subarray(8, 12).toString() === "WEBP") return { mime: "image/webp", ext: "webp" };
  if (b.subarray(0, 4).toString() === "%PDF") return { mime: "application/pdf", ext: "pdf" };
  return null;
}
