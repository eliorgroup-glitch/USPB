"use client";
import { useState, Suspense } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
function Form() {
  const r = useRouter(); const initial = useSearchParams().get("role") === "OWNER" ? "OWNER" : "BUYER";
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr("");
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>;
    if (!f.phone) delete f.phone;
    const res = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
    if (!res.ok) { const j = await res.json().catch(() => ({})); setBusy(false);
      return setErr(j.issues ? "Vérifiez les champs : mot de passe de 8 caractères minimum avec lettres et chiffres, email et téléphone valides." : j.error ?? "Inscription impossible."); }
    await signIn("credentials", { email: f.email, password: f.password, redirect: false });
    r.push(f.role === "OWNER" ? "/deposer" : "/terrains"); r.refresh();
  }
  return (<form onSubmit={submit} className="mx-auto max-w-sm space-y-4">
    <h1 className="font-display text-3xl font-extrabold">Créer un compte</h1>
    <fieldset className="grid grid-cols-2 gap-2"><legend className="label">Je suis</legend>
      {[["BUYER", "Acheteur"], ["OWNER", "Propriétaire"]].map(([v, l]) => (
        <label key={v} className="flex min-h-11 items-center gap-2 rounded-lg border border-line bg-white px-3"><input type="radio" name="role" value={v} defaultChecked={v === initial} />{l}</label>))}</fieldset>
    <div><label className="label" htmlFor="name">Nom complet</label><input id="name" name="name" required className="field" /></div>
    <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" required className="field" /></div>
    <div><label className="label" htmlFor="phone">Téléphone (facultatif)</label><input id="phone" name="phone" type="tel" className="field" /></div>
    <div><label className="label" htmlFor="password">Mot de passe</label><input id="password" name="password" type="password" required minLength={8} autoComplete="new-password" className="field" /></div>
    {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
    <button className="btn-primary w-full" disabled={busy}>{busy ? "Création…" : "Créer mon compte"}</button></form>);
}
export default function Page() { return <Suspense><Form /></Suspense>; }
