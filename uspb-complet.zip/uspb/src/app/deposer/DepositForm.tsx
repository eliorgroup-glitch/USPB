"use client";
import { useState } from "react";
import { fcfa } from "@/lib/format";
const STEPS = ["Vous", "Terrain", "Localisation", "Prix", "Fichiers", "Récap."];
type F = Record<string, string>;
export function DepositForm({ name, email }: { name: string; email: string }) {
  const [step, setStep] = useState(0); const [f, setF] = useState<F>({});
  const [id, setId] = useState<string | null>(null); const [ref, setRef] = useState<string | null>(null);
  const [msg, setMsg] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const num = (k: string) => (f[k] ? Number(f[k]) : undefined);
  const body = () => ({ title: f.title, description: f.description, price: num("price"), city: f.city, commune: f.commune || undefined, district: f.district || undefined,
    latitude: num("latitude"), longitude: num("longitude"),
    land: { areaSqm: num("areaSqm"), lot: f.lot || undefined, island: f.island || undefined, documentType: f.documentType || undefined, documentInfo: f.documentInfo || undefined } });
  async function call(url: string, method: string, data: unknown) {
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.issues ? "Certains champs sont invalides (titre 5 car. min, description 20 car. min, prix et superficie positifs)." : j.error ?? "Erreur");
    return j;
  }
  async function save(): Promise<string> {
    if (id) { await call(`/api/properties/${id}`, "PATCH", body()); return id; }
    const j = await call("/api/properties", "POST", body()); setId(j.id); setRef(j.reference); return j.id;
  }
  async function run(fn: () => Promise<void>) { setBusy(true); setErr(""); setMsg(""); try { await fn(); } catch (e) { setErr((e as Error).message); } setBusy(false); }
  const draft = () => run(async () => { await save(); setMsg("Brouillon enregistré."); });
  const submit = () => run(async () => { const pid = await save(); await call(`/api/properties/${pid}/status`, "POST", { status: "SUBMITTED" }); setMsg("submitted"); });
  const geo = () => navigator.geolocation?.getCurrentPosition((p) => setF((x) => ({ ...x, latitude: p.coords.latitude.toFixed(6), longitude: p.coords.longitude.toFixed(6) })), () => setErr("Position indisponible : saisissez les coordonnées à la main."));
  if (msg === "submitted") return <div className="mx-auto max-w-lg rounded-xl border border-line bg-white p-6 text-center">
    <h1 className="font-display text-2xl font-extrabold">Votre terrain a bien été soumis à USPB.</h1>
    <p className="mt-3">Référence : <strong>{ref}</strong></p><p className="mt-1 text-sm">Vous serez notifié à chaque étape de la vérification.</p></div>;
  const inp = (k: string, label: string, p: Record<string, unknown> = {}) => <div><label className="label" htmlFor={k}>{label}</label><input id={k} value={f[k] ?? ""} onChange={set(k)} className="field" {...p} /></div>;
  return (<div className="mx-auto max-w-xl space-y-5">
    <h1 className="font-display text-3xl font-extrabold">Vendre mon terrain</h1>
    <ol className="flex gap-1 text-xs" aria-label="Étapes">{STEPS.map((s, i) => <li key={s} aria-current={i === step} className={`flex-1 rounded px-1 py-2 text-center ${i === step ? "bg-brand text-white" : i < step ? "bg-brand-soft" : "bg-line/50"}`}>{s}</li>)}</ol>
    <div className="space-y-4 rounded-xl border border-line bg-white p-5">
      {step === 0 && <><p><strong>{name}</strong><br />{email}</p><p className="text-sm text-ink/70">Ces informations proviennent de votre compte.</p></>}
      {step === 1 && <>{inp("title", "Titre de l'annonce", { required: true })}
        <div><label className="label" htmlFor="description">Description</label><textarea id="description" rows={5} value={f.description ?? ""} onChange={set("description")} className="field py-2" /></div>
        {inp("areaSqm", "Superficie (m²)", { type: "number", min: 1 })}{inp("lot", "Lot")}{inp("island", "Îlot")}{inp("documentType", "Type de document disponible")}{inp("documentInfo", "Informations sur le document")}</>}
      {step === 2 && <>{inp("city", "Ville")}{inp("commune", "Commune")}{inp("district", "Quartier")}
        <button type="button" onClick={geo} className="btn-ghost w-full">Utiliser ma position GPS</button>
        <div className="grid grid-cols-2 gap-2">{inp("latitude", "Latitude", { inputMode: "decimal" })}{inp("longitude", "Longitude", { inputMode: "decimal" })}</div>
        <p className="text-xs text-ink/60">Le public ne voit qu'une position approximative.</p></>}
      {step === 3 && inp("price", "Prix demandé (FCFA)", { type: "number", min: 1 })}
      {step === 4 && id && <Uploader id={id} />}
      {step === 5 && <dl className="space-y-1 text-sm">{[["Titre", f.title], ["Ville", [f.district, f.commune, f.city].filter(Boolean).join(", ")], ["Superficie", f.areaSqm && `${f.areaSqm} m²`], ["Lot / Îlot", `${f.lot || "—"} / ${f.island || "—"}`], ["GPS", f.latitude && `${f.latitude}, ${f.longitude}`], ["Prix", f.price && fcfa(f.price)]].map(([k, v]) => <div key={k as string} className="flex justify-between gap-4"><dt className="text-ink/60">{k}</dt><dd className="text-right font-semibold">{v || "—"}</dd></div>)}</dl>}
    </div>
    {err && <p role="alert" className="text-sm text-red-700">{err}</p>}{msg && <p role="status" className="text-sm text-emerald-800">{msg}</p>}
    <div className="flex flex-wrap gap-2">
      {step > 0 && <button className="btn-ghost" onClick={() => setStep(step - 1)} disabled={busy}>Retour</button>}
      <button className="btn-ghost" onClick={draft} disabled={busy || !f.title}>Enregistrer le brouillon</button>
      {step < 5 ? <button className="btn-primary ml-auto" disabled={busy} onClick={() => (step === 3 ? run(async () => { await save(); setStep(4); }) : setStep(step + 1))}>Continuer</button>
        : <button className="btn-primary ml-auto" onClick={submit} disabled={busy}>{busy ? "Envoi…" : "Soumettre à USPB"}</button>}</div></div>);
}

function Uploader({ id }: { id: string }) {
  const [log, setLog] = useState<string[]>([]); const [busy, setBusy] = useState(false); const [cat, setCat] = useState("LAND_TITLE");
  async function send(files: FileList | null, kind: "image" | "document") {
    if (!files) return; setBusy(true);
    for (const file of Array.from(files)) {
      const fd = new FormData(); fd.set("file", file); fd.set("kind", kind); if (kind === "document") fd.set("category", cat);
      const r = await fetch(`/api/properties/${id}/files`, { method: "POST", body: fd }); const j = await r.json().catch(() => ({}));
      setLog((l) => [...l, r.ok ? `Envoyé : ${file.name}` : `Refusé : ${file.name} (${j.error ?? "échec"})`]);
    }
    setBusy(false);
  }
  return (<div className="space-y-4"><div><label className="label" htmlFor="photos">Photos (JPG, PNG, WebP, 5 Mo max)</label>
    <input id="photos" type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={busy} onChange={(e) => send(e.target.files, "image")} className="field py-2" /></div>
    <div><label className="label" htmlFor="cat">Document</label><select id="cat" value={cat} onChange={(e) => setCat(e.target.value)} className="field">
      <option value="LAND_TITLE">Document foncier</option><option value="IDENTITY">Pièce d'identité</option><option value="SUPPORTING">Justificatif</option></select>
      <label className="label mt-2" htmlFor="doc">Fichier (PDF, JPG, PNG, 10 Mo max)</label><input id="doc" type="file" accept="application/pdf,image/jpeg,image/png" multiple disabled={busy} onChange={(e) => send(e.target.files, "document")} className="field py-2" />
      <p className="mt-1 text-xs text-ink/60">Les documents ne sont visibles que par vous et l'équipe USPB.</p></div>
    <ul aria-live="polite" className="space-y-1 text-sm">{log.map((l, i) => <li key={i}>{l}</li>)}</ul></div>);
}
