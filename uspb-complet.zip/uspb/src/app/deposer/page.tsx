import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { DepositForm } from "./DepositForm";
export const metadata = { title: "Vendre mon terrain" };
export default async function Page() {
  const s = await auth();
  if (!s) redirect("/connexion?next=/deposer");
  if (!s.user.permissions.includes("property:create")) redirect("/");
  return <DepositForm name={s.user.name ?? ""} email={s.user.email ?? ""} />;
}
