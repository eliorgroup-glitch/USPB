"use client";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Suspense } from "react";
function Form() {
  const r = useRouter(); const next = useSearchParams().get("next") ?? "/";
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr("");
    const f = new FormData(e.currentTarget);
    const res = await signIn("credentials", { email: f.get("email"), password: f.get("password"), redirect: false });
    setBusy(false);
    if (res?.error) return setErr("Email ou mot de passe incorrect.");
    r.push(next); r.refresh();
  }
  return (<form onSubmit={submit} className="mx-auto max-w-sm space-y-4">
    <h1 className="font-display text-3xl font-extrabold">Connexion</h1>
    <div><label className="label" htmlFor="email">Email</label><input id="email" name="email" type="email" required autoComplete="email" className="field" /></div>
    <div><label className="label" htmlFor="password">Mot de passe</label><input id="password" name="password" type="password" required autoComplete="current-password" className="field" /></div>
    {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
    <button className="btn-primary w-full" disabled={busy}>{busy ? "Connexion…" : "Se connecter"}</button>
    <p className="text-sm">Pas de compte ? <Link href="/inscription" className="font-semibold text-brand">Créer un compte</Link></p></form>);
}
export default function Page() { return <Suspense><Form /></Suspense>; }
