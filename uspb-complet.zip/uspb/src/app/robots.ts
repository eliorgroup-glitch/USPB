export default function robots() { return { rules: { userAgent: "*", allow: "/", disallow: ["/api/", "/deposer", "/dashboard"] }, sitemap: `${process.env.AUTH_URL}/sitemap.xml` }; }
