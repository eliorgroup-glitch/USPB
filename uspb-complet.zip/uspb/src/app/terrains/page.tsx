import Link from "next/link";
import type { Metadata } from "next";
import { api } from "@/lib/format";
import { PropertyCard } from "@/components/PropertyCard";
export const metadata: Metadata = { title: "Terrains à vendre", description: "Recherchez des terrains par ville, prix, superficie et statut de vérification." };
type Res = { total: number; page: number; pageSize: number; items: any[] };

export default async function Terrains({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const sp = await searchParams;
  const qs = new URLSearchParams(Object.entries(sp).filter(([, v]) => v));
  const data = await api<Res>(`/api/properties?${qs}`);
  const pages = data ? Math.ceil(data.total / data.pageSize) : 0;
  const link = (page: number) => `/terrains?${new URLSearchParams({ ...sp, page: String(page) })}`;
  return (<div className="grid gap-6 lg:grid-cols-[18rem_1fr]">
    <form className="space-y-3 rounded-xl border border-line bg-white p-4 lg:self-start" role="search">
      <div><label className="label" htmlFor="q">Mot-clé ou référence</label><input id="q" name="q" defaultValue={sp.q} className="field" /></div>
      <div><label className="label" htmlFor="city">Ville</label><input id="city" name="city" defaultValue={sp.city} className="field" /></div>
      <div><label className="label" htmlFor="commune">Commune</label><input id="commune" name="commune" defaultValue={sp.commune} className="field" /></div>
      <div className="grid grid-cols-2 gap-2">
        <div><label className="label" htmlFor="minPrice">Prix min</label><input id="minPrice" name="minPrice" type="number" defaultValue={sp.minPrice} className="field" /></div>
        <div><label className="label" htmlFor="maxPrice">Prix max</label><input id="maxPrice" name="maxPrice" type="number" defaultValue={sp.maxPrice} className="field" /></div>
        <div><label className="label" htmlFor="minArea">m² min</label><input id="minArea" name="minArea" type="number" defaultValue={sp.minArea} className="field" /></div>
        <div><label className="label" htmlFor="maxArea">m² max</label><input id="maxArea" name="maxArea" type="number" defaultValue={sp.maxArea} className="field" /></div>
      </div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="verified" value="true" defaultChecked={!!sp.verified} /> Vérifiés uniquement</label>
      <div><label className="label" htmlFor="sort">Trier par</label>
        <select id="sort" name="sort" defaultValue={sp.sort ?? "relevance"} className="field">
          <option value="relevance">Pertinence</option><option value="date">Date</option><option value="price_asc">Prix croissant</option>
          <option value="price_desc">Prix décroissant</option><option value="area_asc">Superficie croissante</option><option value="area_desc">Superficie décroissante</option></select></div>
      <button className="btn-primary w-full">Appliquer les filtres</button>
    </form>
    <section aria-live="polite">
      {!data ? <p className="rounded-xl border border-red-200 bg-red-50 p-4">La recherche est momentanément indisponible. Réessayez dans un instant.</p>
        : data.items.length === 0 ? <div className="rounded-xl border border-line bg-white p-8 text-center"><p className="font-semibold">Aucun terrain ne correspond à ces critères.</p><p className="mt-1 text-sm">Élargissez le budget ou retirez un filtre.</p><Link href="/terrains" className="btn-ghost mt-4">Réinitialiser</Link></div>
        : <><p className="mb-3 text-sm text-ink/70">{data.total} terrain{data.total > 1 ? "s" : ""}</p>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{data.items.map((p) => <PropertyCard key={p.id} p={p} />)}</div>
          {pages > 1 && <nav className="mt-6 flex items-center justify-center gap-3" aria-label="Pagination">
            {data.page > 1 && <Link className="btn-ghost" href={link(data.page - 1)}>Précédent</Link>}
            <span className="text-sm">Page {data.page} / {pages}</span>
            {data.page < pages && <Link className="btn-ghost" href={link(data.page + 1)}>Suivant</Link>}</nav>}</>}
    </section></div>);
}
