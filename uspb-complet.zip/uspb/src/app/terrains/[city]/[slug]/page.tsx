import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { api, fcfa } from "@/lib/format";
import { auth } from "@/lib/auth";
import { PropertyActions } from "@/components/PropertyActions";
import { VerificationBadge } from "@/components/VerificationBadge";
type Ctx = { params: Promise<{ city: string; slug: string }> };
const CHECK: Record<string, string> = { IDENTITY: "Identité du déclarant", LOCATION: "Localisation", LOT: "Lot", ISLAND: "Îlot", AREA: "Superficie", DOCUMENTS: "Documents présentés", PHOTOS: "Photos", ADMINISTRATIVE: "Informations administratives", SITE_VISIT: "Visite terrain", OTHER: "Autres contrôles" };
const STATE: Record<string, string> = { UNVERIFIED: "Non vérifié", IN_PROGRESS: "En cours", COMPLIANT: "Conforme", NON_COMPLIANT: "Non conforme", TO_CLARIFY: "À clarifier" };

export async function generateMetadata({ params }: Ctx): Promise<Metadata> {
  const p = await api<any>(`/api/properties/${(await params).slug}`);
  return p ? { title: p.title, description: p.description.slice(0, 155), openGraph: { title: p.title, description: p.description.slice(0, 155) } } : {};
}
export default async function Fiche({ params }: Ctx) {
  const p = await api<any>(`/api/properties/${(await params).slug}`);
  if (!p) notFound();
  const session = await auth();
  const checks = p.verification?.checks ?? [];
  const jsonLd = { "@context": "https://schema.org", "@type": "Product", name: p.title, description: p.description, sku: p.reference,
    offers: { "@type": "Offer", price: Number(p.price), priceCurrency: "XOF" } };
  return (<article className="grid gap-6 lg:grid-cols-[1fr_22rem]">
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    <div className="space-y-6">
      <div className="flex aspect-[16/9] items-center justify-center rounded-xl bg-brand-soft text-brand-dark">
        {p.images?.[0] ? <img src={`/api/files/${p.images[0].storageKey}`} alt={p.title} className="h-full w-full rounded-xl object-cover" /> : "Aucune photo pour cette annonce"}</div>
      <div><VerificationBadge level={p.verificationBadge} />
        <h1 className="mt-3 font-display text-3xl font-extrabold">{p.title}</h1>
        <p className="mt-1 text-ink/70">{[p.district, p.commune, p.city].filter(Boolean).join(", ")} · Réf. {p.reference}</p></div>
      <section><h2 className="font-display text-xl font-bold">Informations déclarées par le propriétaire</h2>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm">
          <div><dt className="text-ink/60">Superficie</dt><dd className="font-semibold">{Number(p.land?.areaSqm)} m²</dd></div>
          <div><dt className="text-ink/60">Lot / Îlot</dt><dd className="font-semibold">{p.land?.lot ?? "—"} / {p.land?.island ?? "—"}</dd></div>
          <div><dt className="text-ink/60">Type de document</dt><dd className="font-semibold">{p.land?.documentType ?? "Non renseigné"}</dd></div>
          <div><dt className="text-ink/60">Disponibilité</dt><dd className="font-semibold">{p.status === "RESERVED" ? "Réservé" : "Disponible"}</dd></div></dl>
        <p className="mt-4 whitespace-pre-line">{p.description}</p></section>
      <section><h2 className="font-display text-xl font-bold">Contrôles effectués par USPB</h2>
        {checks.length === 0 ? <p className="mt-2 text-sm">Aucun contrôle enregistré pour le moment.</p> :
          <ul className="mt-3 divide-y divide-line rounded-xl border border-line bg-white">{checks.map((c: any) => (
            <li key={c.type} className="flex justify-between p-3 text-sm"><span>{CHECK[c.type]}</span><span className="font-semibold">{STATE[c.status]}</span></li>))}</ul>}
        {p.verification?.verifiedAt && <p className="mt-2 text-xs text-ink/60">Dernière vérification : {new Date(p.verification.verifiedAt).toLocaleDateString("fr-FR")}</p>}</section>
    </div>
    <aside className="space-y-3 rounded-xl border border-line bg-white p-5 lg:self-start">
      <p className="text-3xl font-extrabold text-brand-dark">{fcfa(p.price)}</p>
      <p className="text-sm text-ink/70">Localisation {p.location?.exact ? "exacte" : "approximative"} : {p.location?.lat ?? "—"}, {p.location?.lng ?? "—"}</p>
      <PropertyActions propertyId={p.id} role={session?.user.role ?? null} />
    </aside></article>);
}
