export const metadata = { title: "Comment ça marche ?" };
const FLOWS: [string, string[]][] = [
  ["Vous cherchez un terrain", ["Recherchez", "Comparez", "Consultez les informations", "Demandez une visite", "Contactez USPB"]],
  ["Vous avez un terrain", ["Déclarez votre terrain", "Fournissez les informations", "USPB effectue les contrôles prévus", "Votre annonce est publiée", "Recevez des demandes"]],
  ["USPB", ["Réception", "Contrôle", "Référencement", "Mise en relation", "Suivi"]],
];
export default function Page() {
  return (<div className="space-y-8"><h1 className="font-display text-3xl font-extrabold">Comment ça marche ?</h1>
    {FLOWS.map(([t, steps]) => <section key={t}><h2 className="font-display text-xl font-bold">{t}</h2>
      <ol className="mt-3 list-decimal space-y-1 pl-6">{steps.map((s) => <li key={s}>{s}</li>)}</ol></section>)}</div>);
}
