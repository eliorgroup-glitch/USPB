import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
import { computeCommission } from "@/modules/commission/service";
import { changeStatus } from "@/modules/property/service";
const NEXT: Record<string, string[]> = { PENDING: ["IN_PROGRESS", "COMPLETED", "CANCELLED"], IN_PROGRESS: ["COMPLETED", "CANCELLED"], COMPLETED: [], CANCELLED: [] };
export const PATCH = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("transaction:manage");
  const id = (await params).id;
  const { status } = z.object({ status: z.enum(["IN_PROGRESS", "COMPLETED", "CANCELLED"]) }).parse(await req.json());
  const t = await db.transaction.findUnique({ where: { id }, include: { property: true } });
  if (!t) throw new HttpError(404, "Transaction introuvable");
  if (!NEXT[t.status].includes(status)) throw new HttpError(409, `Transition ${t.status} → ${status} non autorisée.`);
  if (status === "COMPLETED") {
    const c = await computeCommission(Number(t.agreedPrice), t.property.city); // échoue avant toute écriture si aucune règle
    await changeStatus(t.propertyId, user, "SOLD", `Transaction ${id}`);
    await db.$transaction([
      db.transaction.update({ where: { id }, data: { status, closedAt: new Date() } }),
      db.commission.create({ data: { transactionId: id, ruleId: c.rule.id, rateApplied: c.rate, amount: c.amount } }),
    ]);
    await audit(user.id, "transaction.complete", "Transaction", id, undefined, { commission: c.amount, rule: c.rule.name });
    return NextResponse.json({ id, status, commissionAmount: c.amount });
  }
  await db.transaction.update({ where: { id }, data: { status } });
  await audit(user.id, "transaction.status", "Transaction", id, { status: t.status }, { status });
  return NextResponse.json({ id, status });
});
