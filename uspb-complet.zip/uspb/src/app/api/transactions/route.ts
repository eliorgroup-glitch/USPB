import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
export const GET = () => route(async () => {
  await requireUser("transaction:manage");
  const items = await db.transaction.findMany({ orderBy: { createdAt: "desc" }, take: 100,
    include: { property: { select: { reference: true, title: true } }, buyer: { select: { name: true } }, commission: true } });
  return NextResponse.json({ items });
});
export const POST = (req: Request) => route(async () => {
  const user = await requireUser("transaction:manage");
  const d = z.object({ propertyId: z.string(), buyerId: z.string(), agreedPrice: z.coerce.number().int().positive() }).parse(await req.json());
  const p = await db.property.findUnique({ where: { id: d.propertyId } });
  if (!p || !["PUBLISHED", "RESERVED"].includes(p.status)) throw new HttpError(409, "Le terrain doit être publié ou réservé.");
  if (!(await db.user.findFirst({ where: { id: d.buyerId, role: { key: "BUYER" } } }))) throw new HttpError(404, "Acheteur introuvable");
  const t = await db.transaction.create({ data: { ...d, sellerId: p.ownerId } });
  await audit(user.id, "transaction.create", "Transaction", t.id, undefined, { propertyId: d.propertyId, agreedPrice: d.agreedPrice });
  return NextResponse.json({ id: t.id, status: t.status }, { status: 201 });
});
