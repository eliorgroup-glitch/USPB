import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";
import { notifyStaff } from "@/modules/notification/notify";
const schema = z.object({ propertyId: z.string(), details: z.string().max(1000).optional(),
  reason: z.enum(["WRONG_INFO","WRONG_PRICE","ALREADY_SOLD","SUSPICIOUS_DOCUMENT","WRONG_LOCATION","FRAUD","OTHER"]) });
export const POST = (req: Request) => route(async () => {
  const user = await requireUser("report:create");
  rateLimit(`report:${user.id}`, 10, 60 * 60 * 1000);
  const d = schema.parse(await req.json());
  const r = await db.report.create({ data: { ...d, reporterId: user.id } });
  await notifyStaff("report.new", "Nouveau signalement", d.reason, "/dashboard/admin");
  return NextResponse.json({ id: r.id }, { status: 201 });
});
export const GET = () => route(async () => {
  await requireUser("report:manage");
  const items = await db.report.findMany({ orderBy: { createdAt: "desc" }, take: 100,
    include: { property: { select: { reference: true, title: true } }, reporter: { select: { name: true } } } });
  return NextResponse.json({ items });
});
