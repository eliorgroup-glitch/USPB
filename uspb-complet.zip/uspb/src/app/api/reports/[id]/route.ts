import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
export const PATCH = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("report:manage");
  const { status } = z.object({ status: z.enum(["IN_REVIEW", "RESOLVED", "DISMISSED"]) }).parse(await req.json());
  const id = (await params).id;
  await db.report.update({ where: { id }, data: { status, handledById: user.id } });
  await audit(user.id, "report.status", "Report", id, undefined, { status });
  return NextResponse.json({ id, status });
});
