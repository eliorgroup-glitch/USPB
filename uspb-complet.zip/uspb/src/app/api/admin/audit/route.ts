import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
export const GET = (req: Request) => route(async () => {
  await requireUser("audit:read");
  const entity = new URL(req.url).searchParams.get("entity") ?? undefined;
  return NextResponse.json({ items: await db.auditLog.findMany({ where: { entity }, orderBy: { createdAt: "desc" }, take: 200, include: { actor: { select: { name: true } } } }) });
});
