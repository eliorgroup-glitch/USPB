import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
export const PATCH = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const admin = await requireUser("user:manage");
  const id = (await params).id;
  if (id === admin.id) throw new HttpError(409, "Vous ne pouvez pas modifier votre propre compte ici.");
  const { isActive } = z.object({ isActive: z.boolean() }).parse(await req.json());
  await db.user.update({ where: { id }, data: { isActive } });
  await audit(admin.id, isActive ? "user.activate" : "user.deactivate", "User", id);
  return NextResponse.json({ id, isActive });
});
