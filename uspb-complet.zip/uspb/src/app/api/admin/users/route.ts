import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
export const GET = () => route(async () => {
  await requireUser("user:manage");
  return NextResponse.json({ items: await db.user.findMany({ orderBy: { createdAt: "desc" }, take: 200, select: { id: true, name: true, email: true, phone: true, isActive: true, isDemo: true, role: { select: { key: true } } } }) });
});
export const POST = (req: Request) => route(async () => { // création d'agents/admins
  const admin = await requireUser("user:manage");
  const d = z.object({ name: z.string().min(2), email: z.string().email().transform((s) => s.toLowerCase()), role: z.enum(["AGENT", "ADMIN", "BUYER", "OWNER"]),
    password: z.string().min(8).regex(/[A-Za-z]/).regex(/[0-9]/) }).parse(await req.json());
  if (await db.user.findUnique({ where: { email: d.email } })) throw new HttpError(409, "Email déjà utilisé.");
  const u = await db.user.create({ data: { name: d.name, email: d.email, passwordHash: await bcrypt.hash(d.password, 12), role: { connect: { key: d.role } } } });
  await audit(admin.id, "user.create", "User", u.id, undefined, { role: d.role });
  return NextResponse.json({ id: u.id }, { status: 201 });
});
