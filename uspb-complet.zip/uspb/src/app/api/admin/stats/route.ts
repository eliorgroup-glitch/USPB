import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
export const GET = () => route(async () => {
  const user = await requireUser("property:read:any");
  const since = new Date(); since.setMonth(since.getMonth() - 5, 1);
  const [props, users, visits, reports, recent, rev] = await Promise.all([
    db.property.groupBy({ by: ["status"], _count: true }), db.user.groupBy({ by: ["roleId"], _count: true }),
    db.visit.groupBy({ by: ["status"], _count: true }), db.report.count({ where: { status: "OPEN" } }),
    db.property.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
    user.permissions.includes("commission:manage") ? db.commission.aggregate({ _sum: { amount: true } }) : null,
  ]);
  const monthly: Record<string, number> = {};
  recent.forEach((p) => { const k = p.createdAt.toISOString().slice(0, 7); monthly[k] = (monthly[k] ?? 0) + 1; });
  return NextResponse.json({ properties: props, users, visits, openReports: reports, monthlyNewListings: monthly, commissionsTotal: rev ? Number(rev._sum.amount ?? 0) : undefined });
});
