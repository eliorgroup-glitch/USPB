import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
import { ruleSchema } from "@/lib/validation";
export const GET = () => route(async () => { await requireUser("commission:manage"); return NextResponse.json({ items: await db.commissionRule.findMany({ orderBy: [{ active: "desc" }, { priority: "desc" }] }) }); });
export const POST = (req: Request) => route(async () => {
  const user = await requireUser("commission:manage");
  const d = ruleSchema.parse(await req.json());
  const r = await db.commissionRule.create({ data: d });
  await audit(user.id, "commission-rule.create", "CommissionRule", r.id, undefined, JSON.parse(JSON.stringify(d)));
  return NextResponse.json({ id: r.id }, { status: 201 });
});
