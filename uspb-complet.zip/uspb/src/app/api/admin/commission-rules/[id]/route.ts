import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
import { ruleSchema } from "@/lib/validation";
export const PATCH = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("commission:manage");
  const id = (await params).id;
  const d = ruleSchema.innerType().partial().parse(await req.json());
  const before = await db.commissionRule.findUnique({ where: { id } });
  await db.commissionRule.update({ where: { id }, data: d });
  await audit(user.id, "commission-rule.update", "CommissionRule", id, JSON.parse(JSON.stringify(before)), JSON.parse(JSON.stringify(d)));
  return NextResponse.json({ id });
});
