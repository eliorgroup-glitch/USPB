import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { signedPath } from "@/providers/storage";
export const GET = (_: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser();
  const doc = await db.propertyDocument.findUnique({ where: { id: (await params).id }, include: { property: { select: { ownerId: true } } } });
  if (!doc || !(user.permissions.includes("property:read:any") || user.id === doc.property.ownerId)) throw new HttpError(404, "Document introuvable");
  return NextResponse.json({ url: signedPath(doc.storageKey), expiresInSeconds: Number(process.env.SIGNED_URL_TTL_SECONDS ?? 300) });
});
