import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
export const GET = () => route(async () => {
  const user = await requireUser("favorite:manage");
  const favs = await db.favorite.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" },
    include: { property: { include: { land: true, images: { take: 1, orderBy: { position: "asc" } } } } } });
  return NextResponse.json({ items: favs.map((f) => ({ ...f.property, price: Number(f.property.price) })) });
});
export const POST = (req: Request) => route(async () => { // bascule : ajoute ou retire
  const user = await requireUser("favorite:manage");
  const { propertyId } = z.object({ propertyId: z.string() }).parse(await req.json());
  const key = { userId_propertyId: { userId: user.id, propertyId } };
  if (await db.favorite.findUnique({ where: key })) { await db.favorite.delete({ where: key }); return NextResponse.json({ favorited: false }); }
  await db.favorite.create({ data: { userId: user.id, propertyId } });
  return NextResponse.json({ favorited: true }, { status: 201 });
});
