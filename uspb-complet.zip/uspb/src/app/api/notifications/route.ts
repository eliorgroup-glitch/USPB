import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
export const GET = () => route(async () => {
  const user = await requireUser();
  const [items, unread] = await Promise.all([
    db.notification.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 50 }),
    db.notification.count({ where: { userId: user.id, readAt: null } })]);
  return NextResponse.json({ unread, items });
});
export const PATCH = (req: Request) => route(async () => { // sans ids : tout marquer comme lu
  const user = await requireUser();
  const { ids } = z.object({ ids: z.array(z.string()).optional() }).parse(await req.json().catch(() => ({})));
  await db.notification.updateMany({ where: { userId: user.id, readAt: null, ...(ids && { id: { in: ids } }) }, data: { readAt: new Date() } });
  return NextResponse.json({ ok: true });
});
