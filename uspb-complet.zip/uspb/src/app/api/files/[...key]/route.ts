import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { optionalUser } from "@/lib/session";
import { getStorage, validSignature } from "@/providers/storage";
const TYPES: Record<string, string> = { jpg: "image/jpeg", png: "image/png", webp: "image/webp", pdf: "application/pdf" };

export const GET = (req: Request, { params }: { params: Promise<{ key: string[] }> }) => route(async () => {
  const key = (await params).key.join("/");
  const url = new URL(req.url);
  const viewer = await optionalUser();
  if (!key.startsWith("img/")) { // documents sensibles : jamais publics
    const doc = await db.propertyDocument.findFirst({ where: { storageKey: key }, include: { property: { select: { ownerId: true } } } });
    if (!doc) throw new HttpError(404, "Fichier introuvable");
    const signed = validSignature(key, Number(url.searchParams.get("exp")), url.searchParams.get("sig") ?? "");
    const allowed = viewer && (viewer.permissions.includes("property:read:any") || viewer.id === doc.property.ownerId);
    if (!signed && !allowed) throw new HttpError(403, "Accès refusé");
    await db.documentAccessLog.create({ data: { documentId: doc.id, userId: viewer?.id ?? "signed-url", action: "view", ip: req.headers.get("x-forwarded-for") } });
  }
  const data = await getStorage().get(key);
  if (!data) throw new HttpError(404, "Fichier introuvable");
  return new Response(new Uint8Array(data), { headers: { "Content-Type": TYPES[key.split(".").pop()!] ?? "application/octet-stream",
    "X-Content-Type-Options": "nosniff", "Cache-Control": key.startsWith("img/") ? "public, max-age=86400" : "private, no-store" } });
});
