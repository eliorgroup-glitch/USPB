import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { optionalUser, requireUser } from "@/lib/session";
import { listQuerySchema, propertyCreateSchema } from "@/lib/validation";
import { createProperty, requiredChecks, toPublic } from "@/modules/property/service";

export const GET = (req: Request) => route(async () => {
  const q = listQuerySchema.parse(Object.fromEntries(new URL(req.url).searchParams));
  const viewer = await optionalUser();
  const where: Prisma.PropertyWhereInput = {};
  if (q.scope === "all") { if (!viewer?.permissions.includes("property:read:any")) throw new HttpError(403, "Accès refusé"); }
  else if (q.scope === "mine") { if (!viewer) throw new HttpError(401, "Authentification requise"); where.ownerId = viewer.id; }
  else where.status = q.availability ?? { in: ["PUBLISHED", "RESERVED"] };
  if (q.city) where.city = { equals: q.city, mode: "insensitive" };
  if (q.commune) where.commune = { equals: q.commune, mode: "insensitive" };
  if (q.district) where.district = { equals: q.district, mode: "insensitive" };
  if (q.minPrice !== undefined || q.maxPrice !== undefined) where.price = { gte: q.minPrice, lte: q.maxPrice };
  if (q.minArea !== undefined || q.maxArea !== undefined || q.documentType)
    where.land = { areaSqm: { gte: q.minArea, lte: q.maxArea }, ...(q.documentType && { documentType: q.documentType }) };
  if (q.verified) where.verification = { is: { status: "COMPLETED" } };
  if (q.q) where.OR = [{ title: { contains: q.q, mode: "insensitive" } }, { description: { contains: q.q, mode: "insensitive" } },
    { district: { contains: q.q, mode: "insensitive" } }, { reference: { contains: q.q, mode: "insensitive" } }];
  const orderBy: Prisma.PropertyOrderByWithRelationInput =
    q.sort === "price_asc" ? { price: "asc" } : q.sort === "price_desc" ? { price: "desc" } :
    q.sort === "area_asc" ? { land: { areaSqm: "asc" } } : q.sort === "area_desc" ? { land: { areaSqm: "desc" } } :
    { publishedAt: { sort: "desc", nulls: "last" } };
  const [total, items, required] = await Promise.all([
    db.property.count({ where }),
    db.property.findMany({ where, orderBy, skip: (q.page - 1) * q.pageSize, take: q.pageSize,
      include: { land: true, images: { orderBy: { position: "asc" }, take: 1 },
        verification: { select: { status: true, verifiedAt: true, checks: { select: { type: true, status: true } } } } } }),
    requiredChecks(),
  ]);
  return NextResponse.json({ total, page: q.page, pageSize: q.pageSize, items: items.map((p) => toPublic(p, viewer, required)) });
});

export const POST = (req: Request) => route(async () => {
  const user = await requireUser("property:create");
  const input = propertyCreateSchema.parse(await req.json());
  const p = await createProperty(user.id, input);
  return NextResponse.json({ id: p.id, reference: p.reference, status: p.status }, { status: 201 });
});
