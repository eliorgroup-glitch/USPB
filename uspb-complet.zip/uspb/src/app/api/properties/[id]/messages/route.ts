import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";
import { notifyStaff } from "@/modules/notification/notify";
// L'acheteur écrit à USPB à propos d'une annonce (les coordonnées du propriétaire ne sont jamais exposées).
export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("message:send");
  rateLimit(`msg:${user.id}`, 30, 60 * 60 * 1000);
  const propertyId = (await params).id;
  const { body } = z.object({ body: z.string().trim().min(1).max(2000) }).parse(await req.json());
  const p = await db.property.findFirst({ where: { id: propertyId, status: { in: ["PUBLISHED", "RESERVED"] } } });
  if (!p) throw new HttpError(404, "Annonce introuvable");
  const c = await db.conversation.upsert({ where: { propertyId_buyerId: { propertyId, buyerId: user.id } }, create: { propertyId, buyerId: user.id }, update: {} });
  await db.message.create({ data: { conversationId: c.id, senderId: user.id, body } });
  await notifyStaff("message.new", "Nouveau message", `Terrain ${p.reference}`, "/dashboard/admin");
  return NextResponse.json({ conversationId: c.id }, { status: 201 });
});
