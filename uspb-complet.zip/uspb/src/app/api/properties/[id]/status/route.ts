import { NextResponse } from "next/server";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { statusSchema } from "@/lib/validation";
import { changeStatus } from "@/modules/property/service";

export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser();
  const { id } = await params;
  const { status, comment } = statusSchema.parse(await req.json());
  await changeStatus(id, user, status, comment);
  return NextResponse.json({ id, status });
});
