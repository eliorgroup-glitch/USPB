import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { optionalUser, requireUser } from "@/lib/session";
import { propertyUpdateSchema } from "@/lib/validation";
import { requiredChecks, toPublic, updateProperty } from "@/modules/property/service";

type Ctx = { params: Promise<{ id: string }> };

export const GET = (_: Request, { params }: Ctx) => route(async () => {
  const { id } = await params; // id, référence ou slug
  const viewer = await optionalUser();
  const p = await db.property.findFirst({ where: { OR: [{ id }, { reference: id }, { slug: id }] },
    include: { land: true, images: { orderBy: { position: "asc" } },
      verification: { include: { checks: { select: { type: true, status: true, checkedAt: true, comment: true } } } } } });
  const visible = p && (["PUBLISHED", "RESERVED"].includes(p.status) ||
    (viewer && (viewer.id === p.ownerId || viewer.permissions.includes("property:read:any"))));
  if (!p || !visible) throw new HttpError(404, "Annonce introuvable");
  return NextResponse.json(toPublic(p, viewer, await requiredChecks()));
});

export const PATCH = (req: Request, { params }: Ctx) => route(async () => {
  const user = await requireUser();
  const { id } = await params;
  const updated = await updateProperty(id, user, propertyUpdateSchema.parse(await req.json()));
  return NextResponse.json({ id: updated.id, updatedAt: updated.updatedAt });
});
