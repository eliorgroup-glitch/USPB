import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { recordCheck } from "@/modules/verification/service";
type Ctx = { params: Promise<{ id: string }> };
const schema = z.object({
  type: z.enum(["IDENTITY","LOCATION","LOT","ISLAND","AREA","DOCUMENTS","PHOTOS","ADMINISTRATIVE","SITE_VISIT","OTHER"]),
  status: z.enum(["UNVERIFIED","IN_PROGRESS","COMPLIANT","NON_COMPLIANT","TO_CLARIFY"]),
  comment: z.string().max(1000).optional(), evidenceDocId: z.string().optional(),
});
export const GET = (_: Request, { params }: Ctx) => route(async () => {
  await requireUser("verification:write");
  const v = await db.verification.findUnique({ where: { propertyId: (await params).id },
    include: { checks: { include: { agent: { select: { name: true } } } }, history: { orderBy: { createdAt: "desc" } } } });
  return NextResponse.json(v);
});
export const POST = (req: Request, { params }: Ctx) => route(async () => {
  const user = await requireUser("verification:write");
  const d = schema.parse(await req.json());
  const status = await recordCheck((await params).id, user.id, d.type, d.status, d.comment, d.evidenceDocId);
  return NextResponse.json({ verificationStatus: status });
});
