import crypto from "crypto";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";
import { getStorage, sniff } from "@/providers/storage";
const CATEGORIES = ["IDENTITY", "LAND_TITLE", "SUPPORTING"];

export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser();
  const { id } = await params;
  rateLimit(`upload:${user.id}`, 40, 60 * 60 * 1000);
  const p = await db.property.findUnique({ where: { id } });
  if (!p) throw new HttpError(404, "Annonce introuvable");
  const staff = user.permissions.includes("property:update:any");
  if (!staff && !(p.ownerId === user.id && ["DRAFT", "SUBMITTED"].includes(p.status))) throw new HttpError(403, "Accès refusé");
  const form = await req.formData();
  const file = form.get("file"); const kind = form.get("kind");
  if (!(file instanceof File)) throw new HttpError(422, "Fichier manquant");
  const isImage = kind === "image";
  if (file.size > (isImage ? 5 : 10) * 1024 * 1024) throw new HttpError(413, `Fichier trop volumineux (max ${isImage ? 5 : 10} Mo).`);
  const buf = Buffer.from(await file.arrayBuffer());
  const t = sniff(buf);
  if (!t || (isImage ? !t.mime.startsWith("image/") : false)) throw new HttpError(415, isImage ? "Formats acceptés : JPG, PNG, WebP." : "Formats acceptés : PDF, JPG, PNG.");
  const name = crypto.randomUUID();
  if (isImage) {
    const key = `img/${id}/${name}.${t.ext}`; await getStorage().put(key, buf);
    const count = await db.propertyImage.count({ where: { propertyId: id } });
    if (count >= 15) throw new HttpError(409, "15 photos maximum.");
    const img = await db.propertyImage.create({ data: { propertyId: id, storageKey: key, position: count } });
    return NextResponse.json({ id: img.id, storageKey: key }, { status: 201 });
  }
  const category = String(form.get("category"));
  if (!CATEGORIES.includes(category) && !(staff && ["VERIFICATION_REPORT", "TRANSACTION"].includes(category))) throw new HttpError(422, "Catégorie invalide");
  const key = `doc/${id}/${name}.${t.ext}`; await getStorage().put(key, buf);
  const doc = await db.propertyDocument.create({ data: { propertyId: id, category: category as any, storageKey: key,
    fileName: file.name.slice(0, 120), mimeType: t.mime, sizeBytes: buf.length, uploadedBy: user.id } });
  await audit(user.id, "document.upload", "PropertyDocument", doc.id);
  return NextResponse.json({ id: doc.id }, { status: 201 });
});
