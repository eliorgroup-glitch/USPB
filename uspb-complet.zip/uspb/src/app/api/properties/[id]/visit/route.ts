import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { notify, notifyStaff } from "@/modules/notification/notify";
const schema = z.object({ requestedAt: z.coerce.date().refine((d) => d > new Date(), "La date doit être future"),
  people: z.coerce.number().int().min(1).max(20).default(1), comment: z.string().max(1000).optional() });
export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("visit:request");
  const id = (await params).id;
  const p = await db.property.findFirst({ where: { id, status: { in: ["PUBLISHED", "RESERVED"] } } });
  if (!p) throw new HttpError(404, "Annonce introuvable");
  const d = schema.parse(await req.json());
  const v = await db.visit.create({ data: { propertyId: id, buyerId: user.id, ...d } });
  await notify(user.id, "visit.received", "Demande de visite envoyée", `Terrain ${p.reference}`, "/dashboard/acheteur");
  await notifyStaff("visit.received", "Une demande de visite a été reçue", `Terrain ${p.reference}`, "/dashboard/admin");
  return NextResponse.json({ id: v.id, status: v.status }, { status: 201 });
});
