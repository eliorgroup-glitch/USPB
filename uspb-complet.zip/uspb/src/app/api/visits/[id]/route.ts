import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { audit } from "@/lib/audit";
import { notify } from "@/modules/notification/notify";
const schema = z.object({ status: z.enum(["PENDING","CONFIRMED","RESCHEDULED","DONE","CANCELLED"]).optional(),
  scheduledAt: z.coerce.date().optional(), agentId: z.string().optional(), agentNote: z.string().max(1000).optional() });
export const PATCH = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("visit:manage");
  const id = (await params).id;
  const d = schema.parse(await req.json());
  const v = await db.visit.findUnique({ where: { id } });
  if (!v) throw new HttpError(404, "Visite introuvable");
  if ((d.status === "CONFIRMED" || d.status === "RESCHEDULED") && !(d.scheduledAt ?? v.scheduledAt)) throw new HttpError(422, "Indiquez la date de la visite.");
  const u = await db.visit.update({ where: { id }, data: d });
  await audit(user.id, "visit.update", "Visit", id, { status: v.status }, d as any);
  const msg = { CONFIRMED: "Votre visite a été confirmée.", RESCHEDULED: "Votre visite a été reprogrammée.", CANCELLED: "Votre visite a été annulée.", DONE: "Votre visite est marquée comme effectuée." } as const;
  if (d.status && d.status in msg) await notify(v.buyerId, `visit.${d.status.toLowerCase()}`, msg[d.status as keyof typeof msg], undefined, "/dashboard/acheteur");
  return NextResponse.json({ id: u.id, status: u.status });
});
