import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
export const GET = (req: Request) => route(async () => {
  const user = await requireUser();
  const staff = user.permissions.includes("visit:manage");
  const status = new URL(req.url).searchParams.get("status") ?? undefined;
  const items = await db.visit.findMany({ where: { ...(staff ? {} : { buyerId: user.id }), status: status as any },
    orderBy: { createdAt: "desc" }, take: 100,
    include: { property: { select: { reference: true, title: true, city: true } }, buyer: { select: { name: true } }, agent: { select: { name: true } } } });
  return NextResponse.json({ items });
});
