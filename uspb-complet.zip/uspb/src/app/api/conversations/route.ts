import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route } from "@/lib/http";
import { requireUser } from "@/lib/session";
export const GET = () => route(async () => {
  const user = await requireUser("message:send");
  const staff = user.permissions.includes("property:read:any");
  const items = await db.conversation.findMany({ where: staff ? {} : { buyerId: user.id }, orderBy: { createdAt: "desc" }, take: 100,
    include: { property: { select: { reference: true, title: true } }, buyer: { select: { name: true } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 }, _count: { select: { messages: { where: { readAt: null, senderId: { not: user.id } } } } } } });
  return NextResponse.json({ items });
});
