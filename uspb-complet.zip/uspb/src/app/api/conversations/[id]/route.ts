import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { requireUser } from "@/lib/session";
import { notify } from "@/modules/notification/notify";
async function load(id: string, user: { id: string; permissions: string[] }) {
  const c = await db.conversation.findUnique({ where: { id }, include: { property: { select: { reference: true } } } });
  const staff = user.permissions.includes("property:read:any");
  if (!c || (!staff && c.buyerId !== user.id)) throw new HttpError(404, "Conversation introuvable");
  return { c, staff };
}
export const GET = (_: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("message:send");
  const { c } = await load((await params).id, user);
  await db.message.updateMany({ where: { conversationId: c.id, senderId: { not: user.id }, readAt: null }, data: { readAt: new Date() } });
  const messages = await db.message.findMany({ where: { conversationId: c.id }, orderBy: { createdAt: "asc" }, include: { sender: { select: { name: true } } } });
  return NextResponse.json({ conversation: c, messages });
});
export const POST = (req: Request, { params }: { params: Promise<{ id: string }> }) => route(async () => {
  const user = await requireUser("message:send");
  const { c, staff } = await load((await params).id, user);
  const { body } = z.object({ body: z.string().trim().min(1).max(2000) }).parse(await req.json());
  const m = await db.message.create({ data: { conversationId: c.id, senderId: user.id, body } });
  if (staff) await notify(c.buyerId, "message.reply", "USPB a répondu à votre message", `Terrain ${c.property.reference}`, "/dashboard/acheteur");
  return NextResponse.json({ id: m.id }, { status: 201 });
});
