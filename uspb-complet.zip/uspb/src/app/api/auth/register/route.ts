import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { route, HttpError } from "@/lib/http";
import { rateLimit } from "@/lib/rate-limit";
import { registerSchema } from "@/lib/validation";
import { audit } from "@/lib/audit";

export const POST = (req: Request) => route(async () => {
  rateLimit(`register:${req.headers.get("x-forwarded-for") ?? "local"}`, 10, 60 * 60 * 1000);
  const d = registerSchema.parse(await req.json());
  if (await db.user.findUnique({ where: { email: d.email } })) throw new HttpError(409, "Un compte existe déjà avec cet email.");
  const user = await db.user.create({ data: { name: d.name, email: d.email, phone: d.phone,
    passwordHash: await bcrypt.hash(d.password, 12), role: { connect: { key: d.role } } } });
  await audit(user.id, "user.register", "User", user.id, undefined, { role: d.role });
  return NextResponse.json({ id: user.id }, { status: 201 });
});
