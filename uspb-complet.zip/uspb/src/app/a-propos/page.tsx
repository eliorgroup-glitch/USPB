export const metadata = { title: "À propos" };
export default function Page() {
  return (<div className="max-w-2xl space-y-4"><h1 className="font-display text-3xl font-extrabold">Qui sommes-nous ?</h1>
    <p>USPB facilite la recherche immobilière et la mise en relation entre propriétaires et personnes à la recherche de biens.</p>
    <p><strong>Proximité.</strong> Une équipe qui connaît le terrain et accompagne chaque dossier.</p>
    <p><strong>Organisation.</strong> Chaque annonce a une référence unique et un historique de suivi.</p>
    <p><strong>Contrôle.</strong> Les vérifications sont détaillées une par une : ce qui a été contrôlé est affiché, le reste est signalé comme non vérifié.</p>
    <p><strong>Mise en relation.</strong> USPB reste l'intermédiaire : les coordonnées privées ne sont pas exposées.</p>
    <p className="rounded-lg bg-brand-soft p-3 text-sm">USPB n'est pas une autorité foncière. « Vérifié selon la procédure USPB » ne remplace ni un titre foncier ni l'avis d'un notaire ou d'un géomètre.</p></div>);
}
