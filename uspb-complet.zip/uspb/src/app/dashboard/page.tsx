import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
export default async function Page() {
  const s = await auth();
  if (!s) redirect("/connexion?next=/dashboard");
  redirect(s.user.permissions.includes("property:read:any") ? "/dashboard/admin" : "/dashboard/mon-espace");
}
