import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { STATUS } from "@/lib/labels";
import { fcfa } from "@/lib/format";
import { VisitActions } from "./VisitActions";
export const metadata = { title: "Back-office" };
export const dynamic = "force-dynamic";
export default async function Page() {
  const s = await auth();
  if (!s) redirect("/connexion?next=/dashboard/admin");
  if (!s.user.permissions.includes("property:read:any")) redirect("/dashboard");
  const since = new Date(); since.setMonth(since.getMonth() - 5, 1);
  const [byStatus, users, todo, visits, reports, unread, recent, rev] = await Promise.all([
    db.property.groupBy({ by: ["status"], _count: true }), db.user.count(),
    db.property.findMany({ where: { status: { in: ["SUBMITTED", "UNDER_REVIEW", "PARTIALLY_VERIFIED", "ANOMALY", "VERIFIED"] } }, orderBy: { updatedAt: "desc" }, take: 30 }),
    db.visit.findMany({ where: { status: { in: ["RECEIVED", "PENDING", "CONFIRMED", "RESCHEDULED"] } }, orderBy: { requestedAt: "asc" }, take: 20, include: { property: { select: { reference: true } }, buyer: { select: { name: true } } } }),
    db.report.count({ where: { status: "OPEN" } }),
    db.message.count({ where: { readAt: null, sender: { role: { key: "BUYER" } } } }),
    db.property.findMany({ where: { createdAt: { gte: since } }, select: { createdAt: true } }),
    s.user.permissions.includes("commission:manage") ? db.commission.aggregate({ _sum: { amount: true } }) : null,
  ]);
  const count = (st: string) => byStatus.find((b) => b.status === st)?._count ?? 0;
  const months: Record<string, number> = {}; recent.forEach((p) => { const k = p.createdAt.toISOString().slice(0, 7); months[k] = (months[k] ?? 0) + 1; });
  const max = Math.max(1, ...Object.values(months));
  const cards: [string, string | number][] = [["Utilisateurs", users], ["En vérification", count("UNDER_REVIEW") + count("SUBMITTED")], ["Publiés", count("PUBLISHED")], ["Vendus", count("SOLD")], ["Signalements ouverts", reports], ["Messages non lus", unread], ...(rev ? [["Commissions", fcfa(Number(rev._sum.amount ?? 0))] as [string, string]] : [])];
  return (<div className="space-y-8"><h1 className="font-display text-3xl font-extrabold">Back-office</h1>
    <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">{cards.map(([k, v]) => <div key={k} className="rounded-xl border border-line bg-white p-4"><dt className="text-sm text-ink/60">{k}</dt><dd className="font-display text-2xl font-bold">{v}</dd></div>)}</dl>
    <section><h2 className="font-display text-xl font-bold">Nouvelles annonces par mois</h2>
      {Object.keys(months).length === 0 ? <p className="mt-2 text-sm">Aucune annonce sur la période.</p> : <ul className="mt-3 space-y-1">{Object.entries(months).sort().map(([m, n]) => <li key={m} className="flex items-center gap-3 text-sm"><span className="w-16">{m}</span><span className="h-4 rounded bg-brand" style={{ width: `${(n / max) * 70}%` }} /><span>{n}</span></li>)}</ul>}</section>
    <section><h2 className="font-display text-xl font-bold">Dossiers à traiter</h2>
      {todo.length === 0 ? <p className="mt-2 text-sm">Aucun dossier en attente.</p> : <ul className="mt-3 divide-y divide-line rounded-xl border border-line bg-white">{todo.map((p) => <li key={p.id}><Link href={`/dashboard/admin/${p.id}`} className="flex flex-wrap justify-between gap-2 p-3 text-sm hover:bg-brand-soft"><span>{p.reference} · {p.title}</span><span className="font-semibold">{STATUS[p.status]}</span></Link></li>)}</ul>}</section>
    <section><h2 className="font-display text-xl font-bold">Visites à traiter</h2>
      {visits.length === 0 ? <p className="mt-2 text-sm">Aucune visite en cours.</p> : <ul className="mt-3 space-y-2">{visits.map((v) => <li key={v.id} className="rounded-xl border border-line bg-white p-3 text-sm"><p><strong>{v.property.reference}</strong> · {v.buyer.name} · {v.people} pers. · souhaitée le {v.requestedAt.toLocaleString("fr-FR")}</p><VisitActions id={v.id} status={v.status} /></li>)}</ul>}</section></div>);
}
