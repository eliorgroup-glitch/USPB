import Link from "next/link";
const L: [string, string][] = [["/dashboard/admin", "Vue d'ensemble"], ["/dashboard/admin/transactions", "Transactions"], ["/dashboard/admin/commissions", "Commissions"],
  ["/dashboard/admin/messages", "Messages"], ["/dashboard/admin/signalements", "Signalements"], ["/dashboard/admin/utilisateurs", "Utilisateurs"], ["/dashboard/admin/audit", "Audit"]];
export default function Layout({ children }: { children: React.ReactNode }) {
  return (<div className="space-y-6"><nav aria-label="Administration" className="flex flex-wrap gap-2">{L.map(([h, t]) => <Link key={h} href={h} className="btn-ghost !min-h-9 !px-3 text-sm">{t}</Link>)}</nav>{children}</div>);
}
