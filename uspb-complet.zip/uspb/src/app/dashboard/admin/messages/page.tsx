import { db } from "@/lib/db";
import { guard } from "@/lib/guard";
import { ApiForm } from "@/components/ApiForm";
export const metadata = { title: "Messages" }; export const dynamic = "force-dynamic";
export default async function Page() {
  await guard("property:read:any");
  const convs = await db.conversation.findMany({ orderBy: { createdAt: "desc" }, take: 50, include: { property: { select: { reference: true } }, buyer: { select: { name: true } },
    messages: { orderBy: { createdAt: "asc" }, include: { sender: { select: { name: true, role: { select: { key: true } } } } } } } });
  // L'ouverture de la page par le personnel marque les messages des acheteurs comme lus.
  await db.message.updateMany({ where: { readAt: null, conversationId: { in: convs.map((c) => c.id) }, sender: { role: { key: "BUYER" } } }, data: { readAt: new Date() } });
  return (<div className="space-y-4"><h1 className="font-display text-3xl font-extrabold">Messages</h1>
    {convs.length === 0 ? <p className="text-sm">Aucune conversation.</p> : convs.map((c) => <section key={c.id} className="space-y-2 rounded-xl border border-line bg-white p-4">
      <h2 className="font-semibold">{c.property.reference} · {c.buyer.name}</h2>
      <ul className="space-y-1 text-sm">{c.messages.map((m) => <li key={m.id}><strong>{m.sender.role.key === "BUYER" ? m.sender.name : "USPB"} :</strong> {m.body}</li>)}</ul>
      <ApiForm url={`/api/conversations/${c.id}`} submit="Répondre" fields={[{ name: "body", label: "Votre réponse", required: true }]} /></section>)}</div>);
}
