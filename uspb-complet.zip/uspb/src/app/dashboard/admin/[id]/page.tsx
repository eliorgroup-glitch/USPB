import { notFound, redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { STATUS, CHECK } from "@/lib/labels";
import { TRANSITIONS } from "@/modules/property/service";
import { CaseActions } from "./CaseActions";
export const dynamic = "force-dynamic";
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const s = await auth();
  if (!s || !s.user.permissions.includes("property:read:any")) redirect("/connexion");
  const p = await db.property.findUnique({ where: { id: (await params).id }, include: { owner: { select: { name: true, email: true, phone: true } }, land: true, documents: true, images: true,
    verification: { include: { checks: true, history: { orderBy: { createdAt: "desc" }, take: 15 } } }, statusHistory: { orderBy: { createdAt: "desc" }, take: 15 } } });
  if (!p) notFound();
  const next = TRANSITIONS[p.status].filter((t) => t !== "SUBMITTED" && (t !== "PUBLISHED" || s.user.permissions.includes("property:publish")));
  return (<div className="space-y-6"><div><h1 className="font-display text-3xl font-extrabold">{p.reference}</h1><p>{p.title} · <strong>{STATUS[p.status]}</strong></p></div>
    <section className="rounded-xl border border-line bg-white p-4 text-sm"><h2 className="font-display text-lg font-bold">Informations déclarées</h2>
      <p>Propriétaire : {p.owner.name} · {p.owner.email} · {p.owner.phone ?? "—"}</p><p>{[p.district, p.commune, p.city].filter(Boolean).join(", ")} · {Number(p.land?.areaSqm)} m² · lot {p.land?.lot ?? "—"} / îlot {p.land?.island ?? "—"}</p>
      <p>GPS : {p.latitude ?? "—"}, {p.longitude ?? "—"} · {p.images.length} photo(s)</p>
      <p>Documents : {p.documents.length === 0 ? "aucun" : p.documents.map((d) => <a key={d.id} className="mr-2 underline" href={`/api/files/${d.storageKey}`} target="_blank">{d.fileName}</a>)}</p></section>
    {p.verification ? <CaseActions propertyId={p.id} transitions={next} checks={p.verification.checks.map((c) => ({ type: c.type, label: CHECK[c.type], status: c.status, comment: c.comment ?? "" }))} />
      : <p className="text-sm">Le dossier n'a pas encore été soumis : aucune vérification possible.</p>}
    <section><h2 className="font-display text-lg font-bold">Historique</h2><ul className="mt-2 space-y-1 text-sm">{p.statusHistory.map((h) => <li key={h.id}>{h.createdAt.toLocaleString("fr-FR")} · {h.fromStatus ? `${STATUS[h.fromStatus]} → ` : ""}{STATUS[h.toStatus]}{h.comment ? ` (${h.comment})` : ""}</li>)}</ul></section></div>);
}
