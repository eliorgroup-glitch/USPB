"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CHECK_STATE, STATUS } from "@/lib/labels";
type C = { type: string; label: string; status: string; comment: string };
export function CaseActions({ propertyId, checks, transitions }: { propertyId: string; checks: C[]; transitions: string[] }) {
  const r = useRouter(); const [err, setErr] = useState(""); const [ok, setOk] = useState("");
  async function post(url: string, data: unknown, msg: string) {
    setErr(""); setOk("");
    const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    if (!res.ok) return setErr((await res.json().catch(() => ({}))).error ?? "Action impossible.");
    setOk(msg); r.refresh();
  }
  return (<><section className="space-y-3"><h2 className="font-display text-lg font-bold">Contrôles USPB</h2>
    {checks.map((c) => <form key={c.type} className="grid gap-2 rounded-xl border border-line bg-white p-3 sm:grid-cols-[10rem_10rem_1fr_auto] sm:items-center"
      onSubmit={(e) => { e.preventDefault(); const f = new FormData(e.currentTarget); post(`/api/properties/${propertyId}/verification`, { type: c.type, status: f.get("status"), comment: f.get("comment") || undefined }, `${c.label} enregistré.`); }}>
      <span className="font-medium">{c.label}</span>
      <select name="status" defaultValue={c.status} aria-label={`Statut : ${c.label}`} className="field">{Object.entries(CHECK_STATE).map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
      <input name="comment" defaultValue={c.comment} placeholder="Commentaire" aria-label={`Commentaire : ${c.label}`} className="field" /><button className="btn-ghost">Enregistrer</button></form>)}</section>
    <section><h2 className="font-display text-lg font-bold">Statut du dossier</h2>
      <div className="mt-2 flex flex-wrap gap-2">{transitions.length === 0 ? <p className="text-sm">Aucune transition possible.</p> : transitions.map((t) => <button key={t} className="btn-ghost" onClick={() => post(`/api/properties/${propertyId}/status`, { status: t }, `Statut : ${STATUS[t]}`)}>{STATUS[t]}</button>)}</div></section>
    {err && <p role="alert" className="text-red-700">{err}</p>}{ok && <p role="status" className="text-emerald-800">{ok}</p>}</>);
}
