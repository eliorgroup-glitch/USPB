import { db } from "@/lib/db";
import { guard } from "@/lib/guard";
import { ApiForm } from "@/components/ApiForm";
import { ApiButton } from "@/components/ApiButton";
export const metadata = { title: "Utilisateurs" }; export const dynamic = "force-dynamic";
export default async function Page() {
  const me = await guard("user:manage");
  const users = await db.user.findMany({ orderBy: { createdAt: "desc" }, take: 200, include: { role: true } });
  return (<div className="space-y-6"><h1 className="font-display text-3xl font-extrabold">Utilisateurs</h1>
    <ApiForm url="/api/admin/users" submit="Créer le compte" fields={[{ name: "name", label: "Nom", required: true }, { name: "email", label: "Email", type: "email", required: true },
      { name: "role", label: "Rôle", options: [["AGENT", "Agent USPB"], ["ADMIN", "Administrateur"], ["BUYER", "Acheteur"], ["OWNER", "Propriétaire"]] }, { name: "password", label: "Mot de passe provisoire", type: "password", required: true }]} />
    <ul className="space-y-2">{users.map((u) => <li key={u.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white p-3 text-sm">
      <span><strong>{u.name}</strong> · {u.email} · {u.role.label}{u.isDemo ? " · démo" : ""}{u.isActive ? "" : " · désactivé"}</span>
      {u.id !== me.id && <ApiButton url={`/api/admin/users/${u.id}`} body={{ isActive: !u.isActive }} label={u.isActive ? "Désactiver" : "Réactiver"} />}</li>)}</ul></div>);
}
