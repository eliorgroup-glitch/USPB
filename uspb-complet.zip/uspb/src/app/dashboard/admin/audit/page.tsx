import { db } from "@/lib/db";
import { guard } from "@/lib/guard";
export const metadata = { title: "Journal d'audit" }; export const dynamic = "force-dynamic";
export default async function Page() {
  await guard("audit:read");
  const logs = await db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 150, include: { actor: { select: { name: true } } } });
  return (<div className="space-y-4"><h1 className="font-display text-3xl font-extrabold">Journal d'audit</h1>
    {logs.length === 0 ? <p className="text-sm">Aucune action enregistrée.</p> : <ul className="divide-y divide-line rounded-xl border border-line bg-white text-sm">{logs.map((l) => <li key={l.id} className="p-3">
      <strong>{l.actor?.name ?? "Système"}</strong> · {l.action} · {l.entity} <span className="text-ink/60">{l.entityId.slice(0, 8)}</span> · {l.createdAt.toLocaleString("fr-FR")}
      {l.after && <div className="break-all text-xs text-ink/60">{JSON.stringify(l.before ?? {})} → {JSON.stringify(l.after)}</div>}</li>)}</ul>}</div>);
}
