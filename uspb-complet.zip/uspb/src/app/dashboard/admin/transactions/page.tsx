import { db } from "@/lib/db";
import { guard } from "@/lib/guard";
import { fcfa } from "@/lib/format";
import { ApiForm } from "@/components/ApiForm";
import { ApiButton } from "@/components/ApiButton";
export const metadata = { title: "Transactions" }; export const dynamic = "force-dynamic";
const LBL: Record<string, string> = { PENDING: "En attente", IN_PROGRESS: "En cours", COMPLETED: "Terminée", CANCELLED: "Annulée" };
const NEXT: Record<string, [string, string][]> = { PENDING: [["IN_PROGRESS", "Démarrer"], ["COMPLETED", "Conclure la vente"], ["CANCELLED", "Annuler"]], IN_PROGRESS: [["COMPLETED", "Conclure la vente"], ["CANCELLED", "Annuler"]], COMPLETED: [], CANCELLED: [] };
export default async function Page() {
  await guard("transaction:manage");
  const [tx, props, buyers] = await Promise.all([
    db.transaction.findMany({ orderBy: { createdAt: "desc" }, take: 100, include: { property: { select: { reference: true, city: true } }, buyer: { select: { name: true } }, commission: true } }),
    db.property.findMany({ where: { status: { in: ["PUBLISHED", "RESERVED"] } }, select: { id: true, reference: true, title: true } }),
    db.user.findMany({ where: { role: { key: "BUYER" } }, select: { id: true, name: true, email: true } })]);
  return (<div className="space-y-6"><h1 className="font-display text-3xl font-extrabold">Transactions</h1>
    {props.length === 0 || buyers.length === 0 ? <p className="text-sm">Il faut au moins un terrain publié et un acheteur pour enregistrer une transaction.</p> :
      <ApiForm url="/api/transactions" submit="Enregistrer la transaction" fields={[
        { name: "propertyId", label: "Terrain", options: props.map((p) => [p.id, `${p.reference} · ${p.title}`]) },
        { name: "buyerId", label: "Acheteur", options: buyers.map((b) => [b.id, `${b.name} (${b.email})`]) },
        { name: "agreedPrice", label: "Prix convenu (FCFA)", type: "number", required: true }]} />}
    {tx.length === 0 ? <p className="text-sm">Aucune transaction enregistrée.</p> : <ul className="space-y-2">{tx.map((t) => <li key={t.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white p-3 text-sm">
      <span><strong>{t.property.reference}</strong> · {t.buyer.name} · {fcfa(t.agreedPrice.toString())}<br />{LBL[t.status]}{t.commission ? ` · commission ${fcfa(t.commission.amount.toString())}` : ""}</span>
      <span className="flex gap-2">{NEXT[t.status].map(([s, l]) => <ApiButton key={s} url={`/api/transactions/${t.id}`} body={{ status: s }} label={l} />)}</span></li>)}</ul>}</div>);
}
