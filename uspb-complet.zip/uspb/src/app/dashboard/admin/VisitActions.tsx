"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { VISIT } from "@/lib/labels";
export function VisitActions({ id, status }: { id: string; status: string }) {
  const r = useRouter(); const [when, setWhen] = useState(""); const [err, setErr] = useState("");
  async function patch(data: Record<string, unknown>) {
    const res = await fetch(`/api/visits/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    if (!res.ok) return setErr((await res.json()).error ?? "Action impossible."); setErr(""); r.refresh();
  }
  const date = () => (when ? new Date(when).toISOString() : undefined);
  return (<div className="mt-2 flex flex-wrap items-center gap-2"><span className="font-semibold">{VISIT[status]}</span>
    <label className="sr-only" htmlFor={`w${id}`}>Date de la visite</label><input id={`w${id}`} type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} className="field !w-auto" />
    <button className="btn-primary" onClick={() => patch({ status: "CONFIRMED", scheduledAt: date() })}>Confirmer</button>
    <button className="btn-ghost" onClick={() => patch({ status: "RESCHEDULED", scheduledAt: date() })}>Reprogrammer</button>
    <button className="btn-ghost" onClick={() => patch({ status: "DONE" })}>Effectuée</button>
    <button className="btn-ghost" onClick={() => patch({ status: "CANCELLED" })}>Annuler</button>
    {err && <p role="alert" className="w-full text-red-700">{err}</p>}</div>);
}
