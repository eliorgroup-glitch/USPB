import { db } from "@/lib/db";
import { guard } from "@/lib/guard";
import { fcfa } from "@/lib/format";
import { ApiForm } from "@/components/ApiForm";
import { ApiButton } from "@/components/ApiButton";
export const metadata = { title: "Commissions" }; export const dynamic = "force-dynamic";
export default async function Page() {
  await guard("commission:manage");
  const [rules, total] = await Promise.all([db.commissionRule.findMany({ orderBy: [{ active: "desc" }, { priority: "desc" }] }), db.commission.aggregate({ _sum: { amount: true } })]);
  return (<div className="space-y-6"><h1 className="font-display text-3xl font-extrabold">Commissions</h1>
    <p className="text-sm">Total des commissions enregistrées : <strong>{fcfa(Number(total._sum.amount ?? 0))}</strong></p>
    <h2 className="font-display text-xl font-bold">Nouvelle règle</h2>
    <ApiForm url="/api/admin/commission-rules" submit="Créer la règle" fields={[
      { name: "name", label: "Nom", required: true }, { name: "kind", label: "Type", options: [["PERCENT", "Pourcentage"], ["FIXED", "Montant fixe"], ["MIXED", "Pourcentage + montant fixe"]] },
      { name: "percentRate", label: "Taux (%)", type: "number", step: "0.001" }, { name: "fixedAmount", label: "Montant fixe (FCFA)", type: "number" },
      { name: "conditions.minPrice", label: "Prix minimum (condition)", type: "number" }, { name: "conditions.maxPrice", label: "Prix maximum (condition)", type: "number" },
      { name: "conditions.city", label: "Ville (condition)" }, { name: "priority", label: "Priorité", type: "number" }, { name: "validTo", label: "Valable jusqu'au", type: "datetime-local" }]} />
    <h2 className="font-display text-xl font-bold">Règles</h2>
    {rules.length === 0 ? <p className="text-sm">Aucune règle : aucune vente ne pourra être conclue tant qu'une règle active n'existe pas.</p> :
      <ul className="space-y-2">{rules.map((r) => <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white p-3 text-sm">
        <span><strong>{r.name}</strong> · {r.kind === "FIXED" ? "" : `${Number(r.percentRate)} %`} {r.kind === "PERCENT" ? "" : fcfa(Number(r.fixedAmount))} · priorité {r.priority}<br />{r.active ? "Active" : "Désactivée"}{r.conditions ? ` · conditions ${JSON.stringify(r.conditions)}` : ""}</span>
        <ApiButton url={`/api/admin/commission-rules/${r.id}`} body={{ active: !r.active }} label={r.active ? "Désactiver" : "Activer"} /></li>)}</ul>}</div>);
}
