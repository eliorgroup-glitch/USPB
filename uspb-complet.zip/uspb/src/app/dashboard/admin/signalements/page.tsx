import { db } from "@/lib/db";
import { guard } from "@/lib/guard";
import { ApiButton } from "@/components/ApiButton";
export const metadata = { title: "Signalements" }; export const dynamic = "force-dynamic";
const R: Record<string, string> = { WRONG_INFO: "Informations incorrectes", WRONG_PRICE: "Prix incorrect", ALREADY_SOLD: "Terrain déjà vendu", SUSPICIOUS_DOCUMENT: "Document suspect", WRONG_LOCATION: "Localisation incorrecte", FRAUD: "Contenu frauduleux", OTHER: "Autre" };
const S: Record<string, string> = { OPEN: "Ouvert", IN_REVIEW: "En cours", RESOLVED: "Résolu", DISMISSED: "Rejeté" };
export default async function Page() {
  await guard("report:manage");
  const items = await db.report.findMany({ orderBy: { createdAt: "desc" }, take: 100, include: { property: { select: { reference: true } }, reporter: { select: { name: true } } } });
  return (<div className="space-y-4"><h1 className="font-display text-3xl font-extrabold">Signalements</h1>
    {items.length === 0 ? <p className="text-sm">Aucun signalement.</p> : <ul className="space-y-2">{items.map((r) => <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-line bg-white p-3 text-sm">
      <span><strong>{r.property.reference}</strong> · {R[r.reason]} · par {r.reporter.name} · <em>{S[r.status]}</em>{r.details && <><br />{r.details}</>}</span>
      <span className="flex gap-2">{(["IN_REVIEW", "RESOLVED", "DISMISSED"] as const).map((s) => <ApiButton key={s} url={`/api/reports/${r.id}`} body={{ status: s }} label={S[s]} />)}</span></li>)}</ul>}</div>);
}
