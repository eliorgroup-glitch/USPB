import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { STATUS, VISIT } from "@/lib/labels";
import { fcfa } from "@/lib/format";
export const metadata = { title: "Mon espace" };
export const dynamic = "force-dynamic";
export default async function Page() {
  const s = await auth(); if (!s) redirect("/connexion?next=/dashboard");
  const owner = s.user.role === "OWNER";
  const [props, visits, notifs, favs] = await Promise.all([
    owner ? db.property.findMany({ where: { ownerId: s.user.id }, orderBy: { createdAt: "desc" } }) : [],
    db.visit.findMany({ where: owner ? { property: { ownerId: s.user.id } } : { buyerId: s.user.id }, orderBy: { createdAt: "desc" }, take: 20, include: { property: { select: { reference: true } } } }),
    db.notification.findMany({ where: { userId: s.user.id }, orderBy: { createdAt: "desc" }, take: 10 }),
    owner ? 0 : db.favorite.count({ where: { userId: s.user.id } }),
  ]);
  return (<div className="space-y-8"><h1 className="font-display text-3xl font-extrabold">Mon espace</h1>
    {owner && <section><h2 className="font-display text-xl font-bold">Mes terrains</h2>
      {props.length === 0 ? <p className="mt-2">Vous n'avez pas encore déposé de terrain. <Link href="/deposer" className="font-semibold text-brand">Déposer un terrain</Link></p> :
        <ul className="mt-3 divide-y divide-line rounded-xl border border-line bg-white">{props.map((p) => <li key={p.id} className="flex flex-wrap justify-between gap-2 p-3 text-sm"><span>{p.reference} · {p.title}</span><span className="font-semibold">{STATUS[p.status]} · {fcfa(p.price.toString())}</span></li>)}</ul>}</section>}
    {!owner && <p>Terrains en favoris : <strong>{favs}</strong></p>}
    <section><h2 className="font-display text-xl font-bold">Visites</h2>
      {visits.length === 0 ? <p className="mt-2 text-sm">Aucune visite pour le moment.</p> : <ul className="mt-3 divide-y divide-line rounded-xl border border-line bg-white">{visits.map((v) => <li key={v.id} className="flex flex-wrap justify-between gap-2 p-3 text-sm"><span>{v.property.reference}</span><span className="font-semibold">{VISIT[v.status]}{v.scheduledAt ? ` · ${v.scheduledAt.toLocaleString("fr-FR")}` : ""}</span></li>)}</ul>}</section>
    <section><h2 className="font-display text-xl font-bold">Notifications</h2>
      {notifs.length === 0 ? <p className="mt-2 text-sm">Aucune notification.</p> : <ul className="mt-3 space-y-2">{notifs.map((n) => <li key={n.id} className="rounded-lg border border-line bg-white p-3 text-sm"><strong>{n.title}</strong>{n.body && <span> — {n.body}</span>}</li>)}</ul>}</section></div>);
}
