import Link from "next/link";
import { SearchBar } from "@/components/SearchBar";
import { VerificationBadge } from "@/components/VerificationBadge";
export default function Home() {
  return (<>
    <section className="py-8 sm:py-14">
      <h1 className="font-display text-4xl font-extrabold leading-[1.05] sm:text-6xl">Trouvez votre terrain.<br />Vérifiez.<br />Avancez en toute confiance.</h1>
      <p className="mt-5 max-w-2xl text-lg text-ink/80">Recherchez des terrains, consultez les informations disponibles, découvrez leur statut de vérification et entrez en relation avec USPB pour avancer dans votre projet immobilier.</p>
      <div className="mt-8 max-w-4xl"><SearchBar /></div>
      <div className="mt-4 flex flex-wrap gap-3">
        <Link href="/terrains" className="btn-primary">Rechercher un terrain</Link>
        <Link href="/inscription?role=OWNER" className="btn-ghost">Vendre mon terrain</Link>
      </div>
    </section>
    <section className="rounded-xl border border-line bg-white p-6">
      <h2 className="font-display text-2xl font-bold">Comment lire un badge de vérification</h2>
      <p className="mt-2 max-w-2xl text-ink/80">Chaque annonce distingue ce que le propriétaire déclare de ce qu'USPB a contrôlé. Un badge vert n'apparaît que lorsque tous les contrôles requis sont conformes. Il ne vaut pas certification par une autorité foncière.</p>
      <ul className="mt-4 space-y-3">
        <li><VerificationBadge level="GREEN" /><p className="mt-1 text-sm">Les contrôles requis par la procédure USPB sont conformes.</p></li>
        <li><VerificationBadge level="ORANGE" /><p className="mt-1 text-sm">Des contrôles restent à effectuer.</p></li>
        <li><VerificationBadge level="RED" /><p className="mt-1 text-sm">Un point doit être clarifié avant d'aller plus loin.</p></li>
      </ul>
    </section>
  </>);
}
