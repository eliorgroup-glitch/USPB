import { db } from "@/lib/db";
import { propertyHref } from "@/lib/format";
export const dynamic = "force-dynamic";
export default async function sitemap() {
  const base = process.env.AUTH_URL ?? "http://localhost:3000";
  const ps = await db.property.findMany({ where: { status: { in: ["PUBLISHED", "RESERVED"] } }, select: { city: true, slug: true, updatedAt: true } });
  return [{ url: base }, { url: `${base}/terrains` }, ...ps.map((p) => ({ url: base + propertyHref(p), lastModified: p.updatedAt }))];
}
