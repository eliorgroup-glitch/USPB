import type { Metadata } from "next";
import { Bricolage_Grotesque, Source_Sans_3 } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/Header";
const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display" });
const body = Source_Sans_3({ subsets: ["latin"], variable: "--font-body" });
export const metadata: Metadata = {
  title: { default: "USPB — Recherche, vérification et mise en relation immobilière", template: "%s | USPB" },
  description: "Recherchez des terrains, consultez leur statut de vérification et entrez en relation avec USPB.",
  openGraph: { siteName: "USPB", locale: "fr_CI", type: "website" },
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className={`${display.variable} ${body.variable}`}>
      <body><Header /><main className="mx-auto max-w-6xl px-4 py-8">{children}</main>
        <footer className="border-t border-line py-6 text-center text-sm text-ink/60">USPB facilite la recherche et la mise en relation. Elle n'est pas une autorité foncière.</footer></body>
    </html>
  );
}
