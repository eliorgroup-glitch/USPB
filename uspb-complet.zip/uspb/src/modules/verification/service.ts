import type { CheckStatus, CheckType } from "@prisma/client";
import { db } from "@/lib/db";
import { HttpError } from "@/lib/http";
import { requiredChecks } from "@/modules/property/service";

export async function recordCheck(propertyId: string, agentId: string, type: CheckType, status: CheckStatus, comment?: string, evidenceDocId?: string) {
  const v = await db.verification.findUnique({ where: { propertyId }, include: { checks: true } });
  if (!v) throw new HttpError(409, "Le dossier doit d'abord être soumis.");
  const prev = v.checks.find((c) => c.type === type);
  const required = await requiredChecks();
  const after = v.checks.map((c) => (c.type === type ? { ...c, status } : c));
  const vs = after.some((c) => c.status === "NON_COMPLIANT" || c.status === "TO_CLARIFY") ? "ANOMALY"
    : required.every((r) => after.find((c) => c.type === r)?.status === "COMPLIANT") ? "COMPLETED"
    : after.some((c) => c.status === "COMPLIANT") ? "PARTIAL" : after.some((c) => c.status === "IN_PROGRESS") ? "IN_PROGRESS" : "NOT_STARTED";
  await db.$transaction([
    db.verificationCheck.update({ where: { verificationId_type: { verificationId: v.id, type } },
      data: { status, comment, evidenceDocId, agentId, checkedAt: new Date() } }),
    db.verification.update({ where: { id: v.id }, data: { status: vs, agentId, verifiedAt: vs === "COMPLETED" ? new Date() : null } }),
    db.verificationHistory.create({ data: { verificationId: v.id, checkType: type, actorId: agentId, fromStatus: prev?.status, toStatus: status, comment } }),
    db.auditLog.create({ data: { actorId: agentId, action: "verification.check", entity: "Property", entityId: propertyId, before: { type, status: prev?.status }, after: { type, status } } }),
  ]);
  return vs;
}
