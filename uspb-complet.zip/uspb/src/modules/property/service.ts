import type { Prisma, PropertyStatus } from "@prisma/client";
import { db } from "@/lib/db";
import { HttpError } from "@/lib/http";
import { audit } from "@/lib/audit";
import { notify } from "@/modules/notification/notify";
import { z } from "zod";
import { propertyCreateSchema, propertyUpdateSchema } from "@/lib/validation";

type Actor = { id: string; permissions: string[] };
const can = (a: Actor, p: string) => a.permissions.includes(p);
const approx = (n?: number) => (n === undefined ? undefined : Math.round(n * 100) / 100); // ≈ 1 km

export const TRANSITIONS: Record<PropertyStatus, PropertyStatus[]> = {
  DRAFT: ["SUBMITTED"], SUBMITTED: ["UNDER_REVIEW", "REJECTED"],
  UNDER_REVIEW: ["PARTIALLY_VERIFIED", "VERIFIED", "ANOMALY", "REJECTED"],
  PARTIALLY_VERIFIED: ["UNDER_REVIEW", "VERIFIED", "ANOMALY", "REJECTED", "PUBLISHED"],
  VERIFIED: ["PUBLISHED", "ANOMALY", "UNDER_REVIEW"], ANOMALY: ["UNDER_REVIEW", "REJECTED"],
  REJECTED: ["ARCHIVED"], PUBLISHED: ["RESERVED", "SOLD", "ARCHIVED", "ANOMALY"],
  RESERVED: ["PUBLISHED", "SOLD"], SOLD: ["ARCHIVED"], ARCHIVED: [],
};
const CHECKS = ["IDENTITY","LOCATION","LOT","ISLAND","AREA","DOCUMENTS","PHOTOS","ADMINISTRATIVE","SITE_VISIT","OTHER"] as const;

export async function requiredChecks(): Promise<string[]> {
  const s = await db.setting.findUnique({ where: { key: "verification.requiredChecks" } });
  return Array.isArray(s?.value) ? (s!.value as string[]) : ["IDENTITY", "LOCATION", "DOCUMENTS"];
}
/** Badge honnête : vert uniquement si tous les contrôles requis sont CONFORMES et aucun n'est non conforme. */
export function verificationBadge(status: PropertyStatus, checks: { type: string; status: string }[], required: string[]) {
  if (status === "ANOMALY" || checks.some((c) => c.status === "NON_COMPLIANT" || c.status === "TO_CLARIFY")) return "RED";
  const ok = required.every((r) => checks.find((c) => c.type === r)?.status === "COMPLIANT");
  return ok && required.length > 0 ? "GREEN" : "ORANGE";
}

export async function createProperty(ownerId: string, input: z.infer<typeof propertyCreateSchema>) {
  const year = new Date().getFullYear();
  return db.$transaction(async (tx) => {
    const key = `property-${year}`;
    const seq = await tx.sequence.upsert({ where: { key }, create: { key, value: 1 }, update: { value: { increment: 1 } } });
    const reference = `USPB-${year}-${String(seq.value).padStart(6, "0")}`;
    const { land, latitude, longitude, ...rest } = input;
    const p = await tx.property.create({ data: { ...rest, reference, ownerId, latitude, longitude,
      publicLatitude: approx(latitude), publicLongitude: approx(longitude),
      slug: `terrain-${Math.round(land.areaSqm)}m2-${reference.toLowerCase()}`, land: { create: land } } });
    await tx.propertyStatusHistory.create({ data: { propertyId: p.id, toStatus: "DRAFT", actorId: ownerId } });
    await tx.auditLog.create({ data: { actorId: ownerId, action: "property.create", entity: "Property", entityId: p.id, after: { reference } } });
    return p;
  });
}

export async function updateProperty(id: string, actor: Actor, input: z.infer<typeof propertyUpdateSchema>) {
  const p = await db.property.findUnique({ where: { id } });
  if (!p) throw new HttpError(404, "Annonce introuvable");
  const staff = can(actor, "property:update:any");
  const owner = p.ownerId === actor.id && can(actor, "property:update:own");
  if (!staff && !owner) throw new HttpError(403, "Accès refusé");
  if (!staff && !["DRAFT", "SUBMITTED"].includes(p.status)) throw new HttpError(409, "Modification impossible après validation du dossier.");
  const { land, latitude, longitude, exactLocationVisible, ...rest } = input;
  if (exactLocationVisible !== undefined && !staff) throw new HttpError(403, "Seul USPB peut décider de l'affichage exact.");
  const data: Prisma.PropertyUpdateInput = { ...rest, exactLocationVisible, ...(land && { land: { update: land } }) };
  if (latitude !== undefined) { data.latitude = latitude; data.publicLatitude = approx(latitude); }
  if (longitude !== undefined) { data.longitude = longitude; data.publicLongitude = approx(longitude); }
  const updated = await db.property.update({ where: { id }, data });
  await audit(actor.id, "property.update", "Property", id, { price: Number(p.price), title: p.title }, input as Prisma.InputJsonValue);
  return updated;
}

export async function changeStatus(id: string, actor: Actor, to: PropertyStatus, comment?: string) {
  const p = await db.property.findUnique({ where: { id }, include: { verification: { include: { checks: true } } } });
  if (!p) throw new HttpError(404, "Annonce introuvable");
  if (!TRANSITIONS[p.status].includes(to)) throw new HttpError(409, `Transition ${p.status} → ${to} non autorisée.`);
  const ownerSubmit = p.ownerId === actor.id && p.status === "DRAFT" && to === "SUBMITTED";
  if (!ownerSubmit && !can(actor, "property:status:change")) throw new HttpError(403, "Accès refusé");
  if (to === "PUBLISHED") {
    if (!can(actor, "property:publish")) throw new HttpError(403, "Seul un administrateur peut publier.");
    const badge = verificationBadge(p.status, p.verification?.checks ?? [], await requiredChecks());
    if (badge !== "GREEN") throw new HttpError(409, "Publication impossible : les contrôles requis ne sont pas tous conformes.");
  }
  await db.$transaction(async (tx) => {
    await tx.property.update({ where: { id }, data: { status: to, ...(to === "PUBLISHED" && { publishedAt: new Date() }) } });
    await tx.propertyStatusHistory.create({ data: { propertyId: id, fromStatus: p.status, toStatus: to, actorId: actor.id, comment } });
    if (to === "SUBMITTED" && !p.verification) {
      await tx.verification.create({ data: { propertyId: id, checks: { create: CHECKS.map((type) => ({ type })) } } });
    }
    await tx.auditLog.create({ data: { actorId: actor.id, action: "property.status", entity: "Property", entityId: id, before: { status: p.status }, after: { status: to } } });
  });
  const msg: Partial<Record<PropertyStatus, [string, string]>> = {
    SUBMITTED: ["Terrain soumis", "Votre terrain a bien été soumis à USPB."],
    UNDER_REVIEW: ["Vérification en cours", "Votre dossier est en cours de vérification."],
    ANOMALY: ["Information complémentaire", "Une information complémentaire est nécessaire."],
    VERIFIED: ["Terrain validé", "Votre terrain a été validé."], PUBLISHED: ["Terrain publié", "Votre terrain est maintenant publié."],
  };
  const m = msg[to]; if (m) await notify(p.ownerId, `property.${to.toLowerCase()}`, m[0], m[1], `/dashboard/proprietaire/${p.id}`);
}

/** Masque ce qui ne doit pas être public (propriétaire, coordonnées exactes). */
export function toPublic(p: any, viewer: Actor | null, required: string[]) {
  const priv = viewer && (can(viewer, "property:read:any") || viewer.id === p.ownerId);
  const { owner, ownerId, latitude, longitude, publicLatitude, publicLongitude, exactLocationVisible, ...safe } = p;
  const exact = priv || exactLocationVisible;
  return { ...safe,
    location: exact ? { lat: latitude, lng: longitude, exact: true } : { lat: publicLatitude, lng: publicLongitude, exact: false },
    verificationBadge: verificationBadge(p.status, p.verification?.checks ?? [], required) };
}
