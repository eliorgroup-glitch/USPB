import { db } from "@/lib/db";
import { HttpError } from "@/lib/http";
/** Aucun taux en dur : la règle active la plus prioritaire (dates + conditions) est lue en base. */
export async function computeCommission(price: number, city: string, at = new Date()) {
  const rules = await db.commissionRule.findMany({ where: { active: true, validFrom: { lte: at }, OR: [{ validTo: null }, { validTo: { gte: at } }] }, orderBy: { priority: "desc" } });
  const rule = rules.find((r) => {
    const c = (r.conditions ?? {}) as { minPrice?: number; maxPrice?: number; city?: string };
    return (c.minPrice === undefined || price >= c.minPrice) && (c.maxPrice === undefined || price <= c.maxPrice) && (!c.city || c.city.toLowerCase() === city.toLowerCase());
  });
  if (!rule) throw new HttpError(409, "Aucune règle de commission active ne s'applique. Définissez-en une dans Administration > Commissions.");
  const pct = rule.percentRate ? Number(rule.percentRate) : 0, fixed = rule.fixedAmount ? Number(rule.fixedAmount) : 0;
  const amount = Math.round((rule.kind !== "FIXED" ? (price * pct) / 100 : 0) + (rule.kind !== "PERCENT" ? fixed : 0));
  return { rule, amount, rate: rule.kind === "FIXED" ? null : pct };
}
