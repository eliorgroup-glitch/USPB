import { db } from "@/lib/db";
// Notification in-app (réelle). Email/SMS/WhatsApp : ajouter un canal quand un fournisseur est configuré.
export function notify(userId: string, type: string, title: string, body?: string, link?: string) {
  return db.notification.create({ data: { userId, type, title, body, link, channel: "IN_APP", sentAt: new Date() } });
}
export async function notifyStaff(type: string, title: string, body?: string, link?: string) {
  const staff = await db.user.findMany({ where: { isActive: true, role: { key: { in: ["AGENT", "ADMIN"] } } }, select: { id: true } });
  await Promise.all(staff.map((u) => notify(u.id, type, title, body, link)));
}
