import { z } from "zod";
export const registerSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(200).transform((s) => s.toLowerCase()),
  phone: z.string().trim().regex(/^\+?[0-9 ]{8,16}$/, "Téléphone invalide").optional(),
  password: z.string().min(8).max(100).regex(/[A-Za-z]/).regex(/[0-9]/, "Au moins une lettre et un chiffre"),
  role: z.enum(["BUYER", "OWNER"]),
});
const land = z.object({
  areaSqm: z.coerce.number().positive().max(100_000_000),
  lot: z.string().trim().max(50).optional(), island: z.string().trim().max(50).optional(),
  documentType: z.string().trim().max(100).optional(), documentInfo: z.string().trim().max(1000).optional(),
});
export const propertyCreateSchema = z.object({
  type: z.literal("LAND").default("LAND"), // v1 : terrains ; étendre l'enum pour USPB 2.0
  listingKind: z.enum(["SALE", "RENT"]).default("SALE"),
  title: z.string().trim().min(5).max(150), description: z.string().trim().min(20).max(5000),
  price: z.coerce.number().int().positive().max(100_000_000_000),
  city: z.string().trim().min(2).max(80), commune: z.string().trim().max(80).optional(), district: z.string().trim().max(80).optional(),
  latitude: z.coerce.number().min(-90).max(90).optional(), longitude: z.coerce.number().min(-180).max(180).optional(),
  land,
});
export const propertyUpdateSchema = propertyCreateSchema.omit({ type: true }).partial().extend({ land: land.partial().optional() })
  .extend({ exactLocationVisible: z.boolean().optional() });
export const statusSchema = z.object({ status: z.enum(["SUBMITTED","UNDER_REVIEW","PARTIALLY_VERIFIED","VERIFIED","ANOMALY","REJECTED","PUBLISHED","RESERVED","SOLD","ARCHIVED"]), comment: z.string().max(1000).optional() });
export const listQuerySchema = z.object({
  q: z.string().max(100).optional(), city: z.string().optional(), commune: z.string().optional(), district: z.string().optional(),
  minPrice: z.coerce.number().optional(), maxPrice: z.coerce.number().optional(),
  minArea: z.coerce.number().optional(), maxArea: z.coerce.number().optional(),
  documentType: z.string().optional(), verified: z.enum(["true"]).optional(),
  availability: z.enum(["PUBLISHED", "RESERVED"]).optional(),
  scope: z.enum(["public", "mine", "all"]).default("public"),
  sort: z.enum(["relevance", "price_asc", "price_desc", "area_asc", "area_desc", "date"]).default("relevance"),
  page: z.coerce.number().int().min(1).default(1), pageSize: z.coerce.number().int().min(1).max(50).default(12),
});

export const ruleSchema = z.object({
  name: z.string().min(2).max(100), kind: z.enum(["PERCENT", "FIXED", "MIXED"]),
  percentRate: z.coerce.number().min(0).max(100).optional(), fixedAmount: z.coerce.number().int().min(0).optional(),
  conditions: z.object({ minPrice: z.number().optional(), maxPrice: z.number().optional(), city: z.string().optional() }).optional(),
  priority: z.coerce.number().int().default(0), validFrom: z.coerce.date().default(() => new Date()), validTo: z.coerce.date().optional(), active: z.boolean().default(true),
}).refine((r) => (r.kind === "FIXED" || r.percentRate !== undefined) && (r.kind === "PERCENT" || r.fixedAmount !== undefined), "Taux et/ou montant fixe requis selon le type");
