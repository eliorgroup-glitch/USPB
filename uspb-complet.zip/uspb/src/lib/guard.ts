import { redirect } from "next/navigation";
import { auth } from "./auth";
export async function guard(permission: string) {
  const s = await auth();
  if (!s) redirect("/connexion?next=/dashboard/admin");
  if (!s.user.permissions.includes(permission)) redirect("/dashboard");
  return s.user;
}
