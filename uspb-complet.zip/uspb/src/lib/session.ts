import { auth } from "./auth";
import { HttpError } from "./http";
export async function optionalUser() { return (await auth())?.user ?? null; }
export async function requireUser(permission?: string) {
  const user = await optionalUser();
  if (!user) throw new HttpError(401, "Authentification requise");
  if (permission && !user.permissions.includes(permission)) throw new HttpError(403, "Accès refusé");
  return user;
}
