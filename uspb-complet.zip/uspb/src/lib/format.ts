export const fcfa = (n: number | string) => `${new Intl.NumberFormat("fr-FR").format(Number(n))} FCFA`;
export const slugify = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
export const propertyHref = (p: { city: string; slug: string }) => `/terrains/${slugify(p.city)}/${p.slug}`;
export async function api<T>(path: string): Promise<T | null> {
  const base = process.env.AUTH_URL ?? "http://localhost:3000";
  const r = await fetch(base + path, { cache: "no-store" });
  return r.ok ? ((await r.json()) as T) : null;
}
