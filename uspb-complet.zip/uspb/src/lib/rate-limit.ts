import { HttpError } from "./http";
// En mémoire : suffisant pour une instance. En multi-instance, remplacer par Redis (même signature).
const hits = new Map<string, number[]>();
export function rateLimit(key: string, max: number, windowMs: number) {
  const now = Date.now();
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= max) throw new HttpError(429, "Trop de requêtes, réessayez plus tard.");
  recent.push(now); hits.set(key, recent);
}
