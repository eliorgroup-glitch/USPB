import { db } from "./db";
import type { Prisma } from "@prisma/client";
export function audit(actorId: string | null, action: string, entity: string, entityId: string,
  before?: Prisma.InputJsonValue, after?: Prisma.InputJsonValue, ip?: string | null) {
  return db.auditLog.create({ data: { actorId, action, entity, entityId, before, after, ip: ip ?? undefined } });
}
