import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "./db";

const creds = z.object({ email: z.string().email(), password: z.string().min(1) });

export const { handlers, auth, signIn, signOut } = NextAuth({
  session: { strategy: "jwt", maxAge: 60 * 60 * 8 },
  pages: { signIn: "/connexion" },
  providers: [Credentials({
    async authorize(raw) {
      const p = creds.safeParse(raw);
      if (!p.success) return null;
      const u = await db.user.findUnique({ where: { email: p.data.email.toLowerCase() },
        include: { role: { include: { permissions: true } } } });
      if (!u || !u.isActive || !(await bcrypt.compare(p.data.password, u.passwordHash))) return null;
      return { id: u.id, name: u.name, email: u.email, role: u.role.key, permissions: u.role.permissions.map((x) => x.key) };
    },
  })],
  callbacks: {
    jwt({ token, user }) {
      if (user) { token.uid = user.id; token.role = user.role; token.permissions = user.permissions; }
      return token;
    },
    session({ session, token }) {
      session.user.id = token.uid as string;
      session.user.role = token.role as string;
      session.user.permissions = token.permissions as string[];
      return session;
    },
  },
});
