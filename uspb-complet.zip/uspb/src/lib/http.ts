import { NextResponse } from "next/server";
import { ZodError } from "zod";
export class HttpError extends Error { constructor(public status: number, message: string) { super(message); } }
export async function route(fn: () => Promise<Response>): Promise<Response> {
  try { return await fn(); }
  catch (e) {
    if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
    if (e instanceof ZodError) return NextResponse.json({ error: "Données invalides", issues: e.flatten() }, { status: 422 });
    console.error(e);
    return NextResponse.json({ error: "Erreur interne" }, { status: 500 });
  }
}
