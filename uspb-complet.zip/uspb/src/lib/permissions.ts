// Source de vérité des permissions. Le seed les synchronise en base ; l'admin pourra les ajuster ensuite.
export const PERMISSIONS = [
  "property:create", "property:update:own", "property:read:any", "property:update:any",
  "property:status:change", "property:publish",
  "verification:write", "visit:request", "visit:manage", "favorite:manage",
  "message:send", "report:create", "report:manage",
  "user:manage", "transaction:manage", "commission:manage", "settings:manage", "audit:read",
] as const;
export type Permission = (typeof PERMISSIONS)[number];

export const ROLES: Record<string, { label: string; permissions: Permission[] }> = {
  BUYER: { label: "Acheteur", permissions: ["visit:request", "favorite:manage", "message:send", "report:create"] },
  OWNER: { label: "Propriétaire", permissions: ["property:create", "property:update:own", "message:send", "report:create"] },
  AGENT: { label: "Agent USPB", permissions: ["property:read:any", "property:update:any", "property:status:change",
    "verification:write", "visit:manage", "message:send", "report:manage"] },
  ADMIN: { label: "Administrateur", permissions: [...PERMISSIONS] },
};
export const SELF_REGISTER_ROLES = ["BUYER", "OWNER"] as const; // agents/admins créés par un admin
