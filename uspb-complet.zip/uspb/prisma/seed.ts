import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { PERMISSIONS, ROLES } from "../src/lib/permissions";
import { createProperty, changeStatus } from "../src/modules/property/service";
import { recordCheck } from "../src/modules/verification/service";
const db = new PrismaClient();
const DEMO_PASSWORD = process.env.DEMO_PASSWORD ?? "Demo-Uspb-2026";

async function base() {
  for (const key of PERMISSIONS) await db.permission.upsert({ where: { key }, create: { key }, update: {} });
  for (const [key, r] of Object.entries(ROLES))
    await db.role.upsert({ where: { key }, update: { label: r.label, permissions: { set: r.permissions.map((k) => ({ key: k })) } },
      create: { key, label: r.label, permissions: { connect: r.permissions.map((k) => ({ key: k })) } } });
  await db.setting.upsert({ where: { key: "verification.requiredChecks" }, update: {}, create: { key: "verification.requiredChecks", value: ["IDENTITY", "LOCATION", "DOCUMENTS"] } });
}
async function demo() {
  if (process.env.ALLOW_DEMO_SEED !== "true") return console.log("Démo ignorée (ALLOW_DEMO_SEED != true).");
  if (await db.user.findUnique({ where: { email: "admin@demo.uspb.local" } })) return console.log("Données de démo déjà présentes.");
  const hash = await bcrypt.hash(DEMO_PASSWORD, 12);
  const mk = (email: string, name: string, role: string) => db.user.create({ data: { email: `${email}@demo.uspb.local`, name: `[DÉMO] ${name}`, passwordHash: hash, isDemo: true, role: { connect: { key: role } } } });
  const [admin, agent, owner, buyer] = await Promise.all([mk("admin", "Administrateur", "ADMIN"), mk("agent", "Agent USPB", "AGENT"), mk("proprietaire", "Propriétaire", "OWNER"), mk("acheteur", "Acheteur", "BUYER")]);
  const perms = async (id: string) => ({ id, permissions: (await db.permission.findMany({ where: { roles: { some: { users: { some: { id } } } } } })).map((p) => p.key) });
  const [A, G, O] = await Promise.all([perms(admin.id), perms(agent.id), perms(owner.id)]);
  const mkProp = async (title: string, city: string, price: number, area: number, lat: number, lng: number) => {
    const p = await createProperty(owner.id, { type: "LAND", listingKind: "SALE", title, city, price, latitude: lat, longitude: lng,
      description: `[DÉMO] ${title}. Données fictives de démonstration.`, land: { areaSqm: area, lot: "12", island: "4", documentType: "Attestation villageoise" } });
    await db.property.update({ where: { id: p.id }, data: { isDemo: true } });
    await changeStatus(p.id, O, "SUBMITTED"); return p;
  };
  const p1 = await mkProp("Terrain 600 m² à Dimbokro", "Dimbokro", 10_000_000, 600, 6.6506, -4.7058);
  const p2 = await mkProp("Terrain 400 m² à Bouaké", "Bouaké", 6_500_000, 400, 7.6906, -5.0303);
  const p3 = await mkProp("Terrain 800 m² à Yamoussoukro", "Yamoussoukro", 14_000_000, 800, 6.8276, -5.2893);
  await changeStatus(p1.id, G, "UNDER_REVIEW");
  for (const t of ["IDENTITY", "LOCATION", "DOCUMENTS"] as const) await recordCheck(p1.id, agent.id, t, "COMPLIANT", "[DÉMO] contrôle fictif");
  await changeStatus(p1.id, G, "VERIFIED"); await changeStatus(p1.id, A, "PUBLISHED");
  await changeStatus(p2.id, G, "UNDER_REVIEW"); await recordCheck(p2.id, agent.id, "IDENTITY", "COMPLIANT"); await recordCheck(p2.id, agent.id, "LOCATION", "IN_PROGRESS");
  void p3;
  await db.visit.create({ data: { propertyId: p1.id, buyerId: buyer.id, requestedAt: new Date(Date.now() + 7 * 864e5), people: 2, comment: "[DÉMO]" } });
  await db.favorite.create({ data: { userId: buyer.id, propertyId: p1.id } });
  await db.commissionRule.create({ data: { name: "[DÉMO] Règle de démonstration — à remplacer", kind: "PERCENT", percentRate: 5, validFrom: new Date() } });
  console.log(`Démo créée. Comptes : admin|agent|proprietaire|acheteur @demo.uspb.local — mot de passe : ${DEMO_PASSWORD}`);
}
base().then(demo).finally(() => db.$disconnect());
