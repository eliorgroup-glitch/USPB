# USPB — Lot 1 : architecture & données

## Architecture
Monolithe modulaire **Next.js (App Router) + TypeScript**, API en Route Handlers (`/api/*`), **Prisma + PostgreSQL**, Auth.js (sessions, rôle dans le token), Tailwind + shadcn/ui, Zod pour toute validation serveur.
Pourquoi : un seul déploiement simple (Docker), typage de bout en bout, et des *modules* métier isolés qu'on peut extraire plus tard (USPB 2.0/3.0).

Principe clé : `Property` est générique (`type`) ; les champs spécifiques vivent dans une table liée (`LandDetails` aujourd'hui, `HouseDetails` demain).
Les services externes passent par des interfaces (`StorageProvider`, `EmailProvider`, `SmsProvider`, `PaymentProvider`, `MapProvider`) : sans clé, aucun envoi ni paiement n'est simulé comme réel.

## Arborescence cible
```
uspb/
├─ prisma/ schema.prisma, migrations/, seed.ts
├─ src/
│  ├─ app/            (public)/ terrains, a-propos, comment-ca-marche
│  │                  (auth)/ connexion, inscription
│  │                  dashboard/ owner, buyer, agent, admin
│  │                  api/ auth, properties, verifications, visits,
│  │                       favorites, inquiries, messages, notifications,
│  │                       transactions, commissions, reports, admin
│  ├─ modules/        property, verification, visit, messaging,
│  │                  notification, commission, payment, audit, settings
│  ├─ lib/            db, auth, permissions, validation, rate-limit, reference
│  ├─ providers/      storage, email, sms, payment, map (interfaces + drivers)
│  └─ components/     ui/, forms/, property/, dashboard/
├─ docker-compose.yml  .env.example
```

## Lancer ce lot
```
cp .env.example .env        # puis remplir POSTGRES_PASSWORD et AUTH_SECRET
docker compose up -d
npx prisma validate
```

## Lancement local (complet)
```
npm install
cp .env.example .env            # renseigner POSTGRES_PASSWORD, DATABASE_URL, AUTH_SECRET, AUTH_URL=http://localhost:3000
docker compose up -d            # PostgreSQL
npx prisma migrate dev --name init
ALLOW_DEMO_SEED=true npm run db:seed
npm run dev                     # http://localhost:3000
```
Comptes de démonstration (mot de passe `Demo-Uspb-2026`) : admin@, agent@, proprietaire@, acheteur@ `demo.uspb.local`.
Documentation : `docs/API.md` (API) · `docs/DEPLOY.md` (production).
