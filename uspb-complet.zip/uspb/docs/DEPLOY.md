# Déploiement production
Prérequis : un serveur avec Docker + Compose, un nom de domaine, HTTPS (reverse proxy Caddy ou Nginx devant le port 3000).

1. `cp .env.example .env` puis renseigner : `POSTGRES_PASSWORD`, `DATABASE_URL` (hôte `db`), `AUTH_SECRET` (`openssl rand -base64 32`), `AUTH_URL` (https://votre-domaine), `ALLOW_DEMO_SEED=false`.
2. `docker compose -f docker-compose.prod.yml up -d --build` (applique les migrations puis démarre l'app).
3. Créer le premier administrateur : démarrer avec `ALLOW_DEMO_SEED=true` uniquement pour obtenir les rôles, ou insérer un admin via `prisma studio`, puis supprimer les comptes démo depuis Utilisateurs.
4. Définir au moins une règle de commission (Admin > Commissions) : sans règle, aucune vente ne peut être conclue.
5. Sauvegardes : volumes `pgdata` (pg_dump quotidien) et `files` (photos/documents).

Avant la mise en ligne : stockage S3 (le mode local convient à un seul serveur), email/SMS (non branchés), fournisseur de paiement (non branché), politique de confidentialité conforme à la réglementation ivoirienne sur les données personnelles.
