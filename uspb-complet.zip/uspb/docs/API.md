# API USPB
JSON partout. Erreurs : `{ "error": "message" }` (422 avec `issues` pour la validation, 401 non connecté, 403 interdit, 429 trop de requêtes).
Authentification : session Auth.js (cookie). Permission requise indiquée entre crochets.

## Authentification
- `POST /api/auth/register` `{name,email,phone?,password,role: BUYER|OWNER}`
- `POST /api/auth/callback/credentials`, `GET /api/auth/session`, `POST /api/auth/signout` (Auth.js)

## Terrains
- `GET /api/properties` filtres : `q city commune district minPrice maxPrice minArea maxArea documentType verified availability scope(public|mine|all) sort page pageSize`
- `POST /api/properties` [property:create] · `GET|PATCH /api/properties/:id` (id, référence ou slug) [PATCH: property:update:own|any]
- `POST /api/properties/:id/status` `{status,comment?}` [property:status:change, ou propriétaire : brouillon→soumis ; publication : property:publish]
- `POST /api/properties/:id/files` multipart `file, kind=image|document, category` [propriétaire ou staff]
- `GET /api/documents/:id/url` → URL signée temporaire · `GET /api/files/*` (photos publiques, documents protégés)

## Vérification
- `GET|POST /api/properties/:id/verification` `{type,status,comment?,evidenceDocId?}` [verification:write]

## Visites, favoris, signalements
- `POST /api/properties/:id/visit` `{requestedAt,people,comment?}` [visit:request] · `GET /api/visits` · `PATCH /api/visits/:id` [visit:manage]
- `GET|POST /api/favorites` (POST = ajouter/retirer) [favorite:manage]
- `POST /api/reports` [report:create] · `GET /api/reports`, `PATCH /api/reports/:id` [report:manage]

## Messages et notifications
- `POST /api/properties/:id/messages` `{body}` · `GET /api/conversations` · `GET|POST /api/conversations/:id` [message:send]
- `GET|PATCH /api/notifications` (PATCH sans `ids` = tout lire)

## Transactions et commissions
- `GET|POST /api/transactions` `{propertyId,buyerId,agreedPrice}` · `PATCH /api/transactions/:id` `{status}` [transaction:manage] — `COMPLETED` calcule la commission et marque le terrain vendu
- `GET|POST /api/admin/commission-rules`, `PATCH /api/admin/commission-rules/:id` [commission:manage]

## Administration
- `GET /api/admin/stats` [property:read:any] · `GET /api/admin/audit?entity=` [audit:read]
- `GET|POST /api/admin/users`, `PATCH /api/admin/users/:id` `{isActive}` [user:manage]
