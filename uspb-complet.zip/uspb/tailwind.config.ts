import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: { extend: {
    colors: { ink: "#10211F", paper: "#F7F9F8", line: "#D9E2DF", brand: { DEFAULT: "#0E6B5C", dark: "#0A4F44", soft: "#E3F1ED" }, sun: "#E9A23B" },
    fontFamily: { display: ["var(--font-display)", "sans-serif"], sans: ["var(--font-body)", "system-ui", "sans-serif"] },
  } },
} satisfies Config;
